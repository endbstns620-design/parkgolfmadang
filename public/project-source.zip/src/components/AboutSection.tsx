import React from 'react';
import { useSalon } from '../context/SalonContext';
import {
  ShieldCheck,
  Award,
  Sparkles,
  CheckCircle2,
  Heart,
  Droplets,
  Flame,
  PackageCheck,
  Trash2,
  Instagram,
} from 'lucide-react';

export const AboutSection: React.FC = () => {
  const { siteConfig, artists } = useSalon();

  const hygieneSteps = [
    {
      step: '01',
      title: '1단계: 잔여물 세정',
      desc: '의료용 중성 세정액을 이용해 시술 기구 표면의 1차 불순물 완벽 세척',
      icon: Droplets,
    },
    {
      step: '02',
      title: '2단계: 초음파 정밀 분해',
      desc: '42,000Hz 초음파 파동으로 미세 틈새의 미세 분진 및 잔여물까지 분해 세척',
      icon: Sparkles,
    },
    {
      step: '03',
      title: '3단계: 134℃ 오토클레이브 멸균',
      desc: '병원 수술실 기준의 고온 고압 증기 멸균기로 세균 및 바이러스 99.99% 사멸',
      icon: Flame,
    },
    {
      step: '04',
      title: '4단계: 개별 밀봉 & UV 살균',
      desc: '1인 1세트 전용 멸균 파우치 밀봉 후 자외선 UV 살균 챔버 보관',
      icon: PackageCheck,
    },
    {
      step: '05',
      title: '5단계: 1회용 화일 즉시 폐기',
      desc: '피부에 직접 닿는 우드파일, 샌딩블록은 시술 직후 고객님 눈앞에서 100% 폐기',
      icon: Trash2,
    },
  ];

  return (
    <section id="about" className="py-16 sm:py-24 bg-[#FAF6F2] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Title */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <span
            className="text-xs font-bold uppercase tracking-widest block font-sans"
            style={{ color: siteConfig.theme.primaryColor }}
          >
            Philosophy &amp; Master Director
          </span>
          <h2 className="font-serif-luxury text-3xl sm:text-4xl font-bold text-stone-900">
            광소장의 장인 철학과 1:1 맞춤 케어
          </h2>
          <p className="text-sm sm:text-base text-stone-600">
            손톱 본연의 건강함을 지키는 프리미엄 케어와 고객의 분위기에 맞춘 독창적인 1:1 퍼스널 디자인을 선사합니다.
          </p>
        </div>

        {/* Master Kwang Spotlight */}
        <div className="bg-white rounded-2xl overflow-hidden border border-[#E8DDD5] shadow-md p-6 sm:p-10 mb-16">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 sm:gap-12 items-center">
            
            {/* Master Photo */}
            <div className="lg:col-span-5 relative">
              <div className="relative rounded-xl overflow-hidden aspect-3/4 sm:aspect-4/5 shadow-md bg-stone-100 border-2 border-[#FAF2ED]">
                <img
                  src={artists[0]?.image || '/src/assets/images/kwang_director_portrait_1788181089231.jpg'}
                  alt={artists[0]?.name}
                  className="w-full h-full object-cover object-top"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/85 via-black/45 to-transparent p-5 text-white">
                  <div className="text-xs text-amber-300 font-semibold">{artists[0]?.role}</div>
                  <div className="font-serif-luxury text-2xl font-bold">{artists[0]?.name}</div>
                </div>
              </div>
            </div>

            {/* Master Bio & Certifications */}
            <div className="lg:col-span-7 space-y-6">
              <div className="space-y-2">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#FAF2ED] text-[#9E6B5D] text-xs font-bold">
                  <Award className="w-3.5 h-3.5 text-amber-600" />
                  <span>11년 경력 네일 아트 마스터 디렉터</span>
                </div>
                <h3 className="font-serif-luxury text-2xl sm:text-3xl font-bold text-stone-900">
                  “단순한 치장이 아닌, 고객의 손끝에 가장 잘 어울리는 맞춤 실루엣을 디자인합니다.”
                </h3>
              </div>

              <p className="text-sm text-stone-600 leading-relaxed">
                {artists[0]?.bio}
              </p>

              {/* Specialties */}
              <div className="space-y-2">
                <div className="text-xs font-bold text-stone-800 uppercase tracking-wide">
                  대표 전문 시술 분야
                </div>
                <div className="flex flex-wrap gap-2">
                  {artists[0]?.specialties.map((spec, idx) => (
                    <span
                      key={idx}
                      className="px-3 py-1 rounded-md text-xs bg-[#FAF6F2] text-stone-800 border border-[#E8DDD5] font-medium"
                    >
                      {spec}
                    </span>
                  ))}
                </div>
              </div>

              {/* Certifications List */}
              <div className="space-y-2 pt-2 border-t border-stone-100">
                <div className="text-xs font-bold text-stone-800 uppercase tracking-wide">
                  자격 및 수상 내역
                </div>
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-stone-700">
                  {artists[0]?.certifications.map((cert, idx) => (
                    <li key={idx} className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                      <span>{cert}</span>
                    </li>
                  ))}
                </ul>
              </div>

            </div>

          </div>
        </div>

        {/* 5-Step Hygiene System Section */}
        <div className="bg-white rounded-2xl p-6 sm:p-10 border border-[#E8DDD5] shadow-sm">
          <div className="text-center max-w-2xl mx-auto mb-10 space-y-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 text-xs font-bold">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Clean &amp; Safe Salon Promise</span>
            </div>
            <h3 className="font-serif-luxury text-2xl sm:text-3xl font-bold text-stone-900">
              광소장의 5단계 의료용 안심 멸균 시스템
            </h3>
            <p className="text-xs sm:text-sm text-stone-600">
              고객님의 소중한 손발과 눈매의 위생을 위해 병원급 멸균 기기 및 1회용 위생 키트 원칙을 준수합니다.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 sm:gap-6">
            {hygieneSteps.map((step) => {
              const Icon = step.icon;
              return (
                <div
                  key={step.step}
                  className="bg-[#FAF7F5] rounded-xl p-5 border border-[#E8DDD5] flex flex-col justify-between space-y-3 relative group hover:bg-[#F5EFEA] transition-colors"
                >
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <span className="font-serif-luxury text-2xl font-bold text-[#9E6B5D]">
                        {step.step}
                      </span>
                      <div className="p-2 rounded-lg bg-white shadow-2xs text-[#9E6B5D]">
                        <Icon className="w-4 h-4" />
                      </div>
                    </div>
                    <h4 className="font-bold text-sm text-stone-900 mb-1.5">
                      {step.title}
                    </h4>
                    <p className="text-xs text-stone-600 leading-relaxed">
                      {step.desc}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </section>
  );
};
