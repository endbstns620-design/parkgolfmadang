import React, { useState } from 'react';
import { useSalon } from '../context/SalonContext';
import { GalleryItem } from '../types';
import {
  Sparkles,
  Heart,
  Maximize2,
  Calendar,
  X,
  Tag,
  User,
  CheckCircle,
} from 'lucide-react';

export const GallerySection: React.FC = () => {
  const {
    siteConfig,
    gallery,
    likeGalleryItem,
    openBooking,
    selectedGalleryItem,
    openGalleryModal,
    closeGalleryModal,
  } = useSalon();

  const [activeFilter, setActiveFilter] = useState<string>('all');

  const filterTabs = [
    { id: 'all', label: '전체 디자인' },
    { id: 'monthly_art', label: '이달의 아트' },
    { id: 'nail_art', label: '핸드 젤네일' },
    { id: 'eyelash', label: '속눈썹 펌/연장' },
    { id: 'special', label: '웨딩 & 스페셜' },
    { id: 'pedicure', label: '페디큐어' },
  ];

  const filteredItems =
    activeFilter === 'all'
      ? gallery
      : gallery.filter((item) => item.category === activeFilter);

  return (
    <section id="gallery" className="py-16 sm:py-24 bg-white border-t border-[#EAE3DE]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 space-y-3">
          <span
            className="text-xs font-bold uppercase tracking-widest block font-sans"
            style={{ color: siteConfig.theme.primaryColor }}
          >
            Portfolio Artworks
          </span>
          <h2 className="font-serif-luxury text-3xl sm:text-4xl font-bold text-stone-900">
            광소장 디자인 포트폴리오
          </h2>
          <p className="text-sm sm:text-base text-stone-600">
            매 시즌 감각적인 컬러링과 꼼꼼한 마감으로 완성된 실제 고객 시술 갤러리입니다.
          </p>
        </div>

        {/* Filter Navigation */}
        <div className="flex items-center justify-start sm:justify-center overflow-x-auto pb-4 gap-2 no-scrollbar mb-10">
          {filterTabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveFilter(tab.id)}
              className={`px-4 py-2 rounded-full text-xs sm:text-sm font-semibold whitespace-nowrap transition-all ${
                activeFilter === tab.id
                  ? 'text-white shadow-xs'
                  : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
              }`}
              style={
                activeFilter === tab.id
                  ? { backgroundColor: siteConfig.theme.primaryColor }
                  : {}
              }
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className="group relative bg-stone-100 rounded-xl overflow-hidden shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col border border-stone-200"
            >
              {/* Photo */}
              <div
                onClick={() => openGalleryModal(item)}
                className="relative aspect-square overflow-hidden cursor-pointer bg-stone-200"
              >
                <img
                  src={item.imageUrl}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                  <div className="bg-white/90 text-stone-800 p-2.5 rounded-full shadow-lg transform translate-y-2 group-hover:translate-y-0 transition-transform">
                    <Maximize2 className="w-4 h-4 text-stone-800" />
                  </div>
                </div>

                {/* Badge if monthly art */}
                {item.isMonthlyArt && (
                  <div className="absolute top-2.5 left-2.5 bg-amber-600 text-white text-[9px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 shadow-xs">
                    <Sparkles className="w-2.5 h-2.5" />
                    <span>이달의 아트</span>
                  </div>
                )}
              </div>

              {/* Info Bottom */}
              <div className="p-3.5 bg-white flex flex-col justify-between flex-1">
                <div>
                  <div className="flex items-center justify-between text-[11px] text-stone-500 mb-1">
                    <span className="font-medium">{item.categoryLabel}</span>
                    <span className="text-[10px] text-stone-400">{item.artist}</span>
                  </div>
                  <h4
                    onClick={() => openGalleryModal(item)}
                    className="font-serif-luxury text-sm font-bold text-stone-900 line-clamp-1 cursor-pointer hover:text-[#9E6B5D] transition-colors"
                  >
                    {item.title}
                  </h4>
                </div>

                <div className="mt-2.5 pt-2 border-t border-stone-100 flex items-center justify-between">
                  <span className="text-xs font-bold text-stone-800">
                    {item.price ? `₩${item.price.toLocaleString()}` : '상담 후 책정'}
                  </span>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      likeGalleryItem(item.id);
                    }}
                    className="flex items-center gap-1 text-stone-400 hover:text-rose-500 transition-colors p-1"
                    title="좋아요"
                  >
                    <Heart className="w-3.5 h-3.5 fill-rose-50 hover:fill-rose-500 text-rose-500 transition-all" />
                    <span className="text-[11px] font-medium text-stone-600">{item.likes}</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Gallery Zoom Modal */}
        {selectedGalleryItem && (
          <div
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
            onClick={closeGalleryModal}
          >
            <div
              className="bg-white rounded-2xl max-w-3xl w-full overflow-hidden shadow-2xl animate-in zoom-in-95 duration-200 border border-stone-200 relative"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Close Button */}
              <button
                onClick={closeGalleryModal}
                className="absolute top-4 right-4 z-10 p-2 rounded-full bg-black/60 text-white hover:bg-black transition-colors"
                aria-label="닫기"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="grid grid-cols-1 md:grid-cols-2">
                {/* Photo Side */}
                <div className="aspect-square bg-stone-100 relative">
                  <img
                    src={selectedGalleryItem.imageUrl}
                    alt={selectedGalleryItem.title}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>

                {/* Info Side */}
                <div className="p-6 sm:p-8 flex flex-col justify-between space-y-6">
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-[#FAF2ED] text-[#9E6B5D]">
                        {selectedGalleryItem.categoryLabel}
                      </span>
                      {selectedGalleryItem.isMonthlyArt && (
                        <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800 flex items-center gap-1">
                          <Sparkles className="w-3 h-3" /> 이달의 아트
                        </span>
                      )}
                    </div>

                    <h3 className="font-serif-luxury text-2xl font-bold text-stone-900">
                      {selectedGalleryItem.title}
                    </h3>

                    <p className="text-sm text-stone-600 leading-relaxed">
                      {selectedGalleryItem.description}
                    </p>

                    {/* Metadata */}
                    <div className="space-y-2 pt-2 border-t border-stone-100 text-xs text-stone-700">
                      <div className="flex items-center gap-2">
                        <User className="w-3.5 h-3.5 text-stone-400" />
                        <span>담당 아티스트: <strong>{selectedGalleryItem.artist}</strong></span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Tag className="w-3.5 h-3.5 text-stone-400" />
                        <span>시술 예상가: <strong>₩{selectedGalleryItem.price?.toLocaleString()}</strong></span>
                      </div>
                    </div>

                    {/* Tags */}
                    <div className="flex flex-wrap gap-1.5 pt-2">
                      {selectedGalleryItem.tags.map((t, idx) => (
                        <span
                          key={idx}
                          className="text-xs bg-stone-100 text-stone-600 px-2.5 py-1 rounded-md"
                        >
                          #{t}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="space-y-2 pt-4 border-t border-stone-100">
                    <button
                      onClick={() => {
                        closeGalleryModal();
                        openBooking();
                      }}
                      className="w-full py-3.5 rounded-md text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-sm hover:opacity-90 active:scale-98 transition-all"
                      style={{ backgroundColor: siteConfig.theme.primaryColor }}
                    >
                      <Calendar className="w-4 h-4" />
                      <span>이 디자인으로 상담 및 예약하기</span>
                    </button>
                    <p className="text-[11px] text-center text-stone-500">
                      * 고객님의 손톱 바디 크기 및 취향에 맞춰 컬러/파츠 맞춤 변경 가능합니다.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

      </div>
    </section>
  );
};
