var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_genai = require("@google/genai");
var import_vite = require("vite");
var import_dotenv = __toESM(require("dotenv"), 1);
import_dotenv.default.config();
var aiClient = null;
function getGeminiAI() {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is required.");
    }
    aiClient = new import_genai.GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build"
        }
      }
    });
  }
  return aiClient;
}
async function startServer() {
  const app = (0, import_express.default)();
  const PORT = 3e3;
  app.use(import_express.default.json());
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok" });
  });
  app.post("/api/gemini/analyze-blog", async (req, res) => {
    try {
      const { title, blogUrl, roughContent, category } = req.body;
      if (!title && !blogUrl && !roughContent) {
        return res.status(400).json({ error: "\uC81C\uBAA9, \uBE14\uB85C\uADF8 URL \uB610\uB294 \uB0B4\uC6A9\uC744 \uC785\uB825\uD574\uC8FC\uC138\uC694." });
      }
      let fetchedBlogSnippet = "";
      if (blogUrl && blogUrl.startsWith("http")) {
        try {
          let targetUrl = blogUrl;
          if (blogUrl.includes("blog.naver.com") && !blogUrl.includes("m.blog.naver.com")) {
            targetUrl = blogUrl.replace("blog.naver.com", "m.blog.naver.com");
          }
          const fetchRes = await fetch(targetUrl, {
            headers: {
              "User-Agent": "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)"
            },
            signal: AbortSignal.timeout(4e3)
          });
          if (fetchRes.ok) {
            const html = await fetchRes.text();
            const cleanText = html.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "").replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, "").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").slice(0, 2500);
            fetchedBlogSnippet = cleanText;
          }
        } catch {
        }
      }
      const prompt = `
\uB2F9\uC2E0\uC740 \uCC9C\uC548\xB7\uC544\uC0B0 \uC9C0\uC5ED\uC758 \uBCA0\uD14C\uB791 \uACF5\uC778\uC911\uAC1C\uC0AC '\uAD11\uC18C\uC7A5'\uC758 \uC804\uBB38 \uBD80\uB3D9\uC0B0 \uB9AC\uD3EC\uD2B8 \uC791\uC131 AI \uC5B4\uC2DC\uC2A4\uD134\uD2B8\uC785\uB2C8\uB2E4.
\uC0AC\uC6A9\uC790\uAC00 \uC785\uB825\uD55C \uBE14\uB85C\uADF8 \uAE00 \uC815\uBCF4(\uC81C\uBAA9: "${title || ""}", \uB9C1\uD06C: "${blogUrl || ""}", \uCE74\uD14C\uACE0\uB9AC: "${category || ""}", \uC218\uC9D1\uB41C \uB0B4\uC6A9: "${fetchedBlogSnippet.slice(0, 1e3) || roughContent || ""}")\uB97C \uC2EC\uCE35 \uBD84\uC11D\uD558\uC5EC \uBC29\uBB38\uC790\uB4E4\uC774 \uC2E0\uB8B0\uD560 \uC218 \uC788\uB294 \uC804\uBB38\uC801\uC778 3\uC904 \uC694\uC57D \uBC0F \uC0C1\uC138 \uBE0C\uB9AC\uD551 \uB9AC\uD3EC\uD2B8\uB97C \uC0DD\uC131\uD574\uC8FC\uC138\uC694.

\uBC18\uB4DC\uC2DC \uC544\uB798 JSON \uD615\uC2DD\uC5D0 \uB9DE\uCD94\uC5B4 \uC751\uB2F5\uD574\uC8FC\uC138\uC694:
- title: \uB9E4\uB825\uC801\uC774\uACE0 \uC804\uBB38\uC801\uC778 \uCE7C\uB7FC \uC81C\uBAA9 (\uAE30\uC874 \uC81C\uBAA9\uC774 \uC788\uC73C\uBA74 \uB2E4\uB4EC\uAC70\uB098 \uC720\uC9C0)
- category: ["\uC2E4\uAC70\uB798\uAC00 \uBD84\uC11D", "\uC138\uBB34 / \uBC95\uB960 \uD301", "\uC9C0\uC5ED \uAC1C\uBC1C \uD638\uC7AC", "\uC2DC\uC7A5 \uBE0C\uB9AC\uD551", "\uBD80\uB3D9\uC0B0 \uC0C1\uC2DD"] \uC911 \uAC00\uC7A5 \uC801\uD569\uD55C 1\uAC1C
- excerpt: \uCE74\uB4DC\uC5D0 \uB178\uCD9C\uB420 \uBA85\uD655\uD558\uACE0 \uC2E0\uB8B0\uAC10 \uC788\uB294 \uD575\uC2EC \uC694\uC57D 2~3\uC904 (\uC904\uBC14\uAFC8 \uC5C6\uC774 \uAC04\uACB0\uD558\uACE0 \uBA85\uD655\uD55C \uBB38\uC7A5)
- content: 3~4\uAC1C \uB2E8\uB77D\uC73C\uB85C \uAD6C\uC131\uB41C \uC0C1\uC138 \uBD84\uC11D \uBCF8\uBB38 (\uC2E4\uAC70\uB798 \uD750\uB984, \uC785\uC9C0 \uD638\uC7AC, \uC8FC\uC758\uC0AC\uD56D, \uAD11\uC18C\uC7A5\uC758 \uD22C\uC790/\uC2E4\uAC70\uC8FC \uC870\uC5B8 \uB4F1)
- tags: \uAC80\uC0C9\uC6A9 \uD0DC\uADF8 3~5\uAC1C \uBC30\uC5F4 (\uC608: ["\uCC9C\uC548\uC544\uC0B0", "\uC2E4\uAC70\uB798\uAC00", "\uBD88\uB2F9\uB3D9", "\uBD84\uC591\uAD8C", "\uC138\uBB34\uC0C1\uC2DD"])
- readTimeMinutes: \uC608\uC0C1 \uC77D\uAE30 \uC2DC\uAC04 (\uC815\uC218 2~6)
- suggestedThumbnail: \uC8FC\uC81C\uC5D0 \uC5B4\uC6B8\uB9AC\uB294 \uCD94\uCC9C \uACE0\uD654\uC9C8 \uBD80\uB3D9\uC0B0 \uC774\uBBF8\uC9C0 \uD0A4\uC6CC\uB4DC \uB610\uB294 unsplash URL
`;
      const ai = getGeminiAI();
      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: import_genai.Type.OBJECT,
            properties: {
              title: { type: import_genai.Type.STRING },
              category: { type: import_genai.Type.STRING },
              excerpt: { type: import_genai.Type.STRING },
              content: { type: import_genai.Type.STRING },
              tags: {
                type: import_genai.Type.ARRAY,
                items: { type: import_genai.Type.STRING }
              },
              readTimeMinutes: { type: import_genai.Type.INTEGER },
              suggestedThumbnail: { type: import_genai.Type.STRING }
            },
            required: ["title", "category", "excerpt", "content", "tags", "readTimeMinutes"]
          }
        }
      });
      const parsedData = JSON.parse(response.text || "{}");
      return res.json({
        success: true,
        data: parsedData
      });
    } catch (error) {
      console.error("Gemini blog analysis error:", error);
      return res.status(500).json({
        error: error.message || "\uBE14\uB85C\uADF8 \uBD84\uC11D \uC911 \uC624\uB958\uAC00 \uBC1C\uC0DD\uD588\uC2B5\uB2C8\uB2E4.",
        fallback: {
          excerpt: "\uCC9C\uC548\xB7\uC544\uC0B0 \uC9C0\uC5ED\uC758 \uD575\uC2EC \uC2E4\uAC70\uB798 \uB3D9\uD5A5 \uBC0F \uBD80\uB3D9\uC0B0 \uC815\uBCF4\uB97C \uBD84\uC11D\uD55C \uAD11\uC18C\uC7A5 \uC804\uBB38 \uB9AC\uD3EC\uD2B8\uC785\uB2C8\uB2E4.",
          content: "\uD574\uB2F9 \uCE7C\uB7FC\uC758 \uC0C1\uC138 \uB0B4\uC6A9\uC740 \uB124\uC774\uBC84 \uBE14\uB85C\uADF8 \uC6D0\uBB38 \uB9C1\uD06C\uB97C \uD1B5\uD574 \uD655\uC778\uD558\uC2E4 \uC218 \uC788\uC2B5\uB2C8\uB2E4.",
          tags: ["\uCC9C\uC548\uC544\uC0B0", "\uBD80\uB3D9\uC0B0\uCE7C\uB7FC", "\uAD11\uC18C\uC7A5"],
          readTimeMinutes: 3
        }
      });
    }
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
