import React, { useState, useEffect } from 'react';
import { useSalon } from '../context/SalonContext';
import { ServiceItem, ServiceCategory } from '../types';
import confetti from 'canvas-confetti';
import { submitToFormspree } from '../utils/formspree';
import {
  X,
  Calendar,
  Clock,
  User,
  Phone,
  Sparkles,
  CheckCircle2,
  ChevronRight,
  ChevronLeft,
  Tag,
  ShieldCheck,
  CreditCard,
  Copy,
  MessageCircle,
} from 'lucide-react';

const ADD_ON_OPTIONS = [
  { id: 'opt-off', name: '타샵 젤 제거 (쏙오프)', price: 15000, desc: '자샵 시술 시 제거는 무료' },
  { id: 'opt-parts', name: '시그니처 파츠/스톤 2ea 추가', price: 15000, desc: '스와로브스키 및 엠보 파츠' },
  { id: 'opt-overlay', name: '프리미엄 빌더젤 오버레이', price: 10000, desc: '손톱 꺾임 방지 및 5주 유지력 강화' },
  { id: 'opt-lash-tint', name: '속눈썹 블랙 틴팅 코팅', price: 10000, desc: '마스카라 효과 및 또렷한 눈매' },
  { id: 'opt-keratin', name: '고농축 케라틴 수분 앰플', price: 10000, desc: '속눈썹 손상 방지 단백질 공급' },
];

const TIME_SLOTS = [
  '10:30', '11:45', '13:00', '14:15', '15:30', '16:45', '18:00', '19:15'
];

export const BookingModal: React.FC = () => {
  const {
    siteConfig,
    services,
    artists,
    isBookingOpen,
    closeBooking,
    selectedServiceForBooking,
    addReservation,
    showToast,
  } = useSalon();

  const [step, setStep] = useState<1 | 2 | 3 | 4 | 5>(1);

  // Form State
  const [selectedService, setSelectedService] = useState<ServiceItem | null>(null);
  const [selectedAddOns, setSelectedAddOns] = useState<string[]>([]);
  const [selectedArtist, setSelectedArtist] = useState<string>('art-1');
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [selectedTime, setSelectedTime] = useState<string>('13:00');
  const [customerName, setCustomerName] = useState<string>('');
  const [customerPhone, setCustomerPhone] = useState<string>('');
  const [requestNotes, setRequestNotes] = useState<string>('');

  // Result state
  const [confirmedReservationId, setConfirmedReservationId] = useState<string>('');

  // Initialize service if preselected
  useEffect(() => {
    if (selectedServiceForBooking) {
      setSelectedService(selectedServiceForBooking);
      setStep(1);
    } else if (services.length > 0 && !selectedService) {
      setSelectedService(services[0]);
    }
  }, [selectedServiceForBooking, services]);

  // Set default date to tomorrow if not set
  useEffect(() => {
    if (!selectedDate) {
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      setSelectedDate(tomorrow.toISOString().split('T')[0]);
    }
  }, [selectedDate]);

  if (!isBookingOpen) return null;

  // Calculate pricing
  const basePrice = selectedService ? selectedService.price : 0;
  const addOnsTotal = selectedAddOns.reduce((sum, addOnName) => {
    const found = ADD_ON_OPTIONS.find((o) => o.name === addOnName);
    return sum + (found ? found.price : 0);
  }, 0);
  const totalPrice = basePrice + addOnsTotal;
  const depositAmount = 20000;

  const handleAddOnToggle = (name: string) => {
    setSelectedAddOns((prev) =>
      prev.includes(name) ? prev.filter((item) => item !== name) : [...prev, name]
    );
  };

  const handleFinalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || !customerPhone.trim() || !selectedService) {
      showToast('입력 확인 필요', '성함과 연락처를 정확히 입력해주세요.', 'error');
      return;
    }

    const artistObj = artists.find((a) => a.id === selectedArtist) || artists[0];

    const created = addReservation({
      customerName: customerName.trim(),
      phone: customerPhone.trim(),
      date: selectedDate,
      time: selectedTime,
      artistId: artistObj.id,
      artistName: artistObj.name,
      serviceId: selectedService.id,
      serviceName: selectedService.name,
      category: selectedService.category,
      addOns: selectedAddOns,
      requestNotes: requestNotes.trim(),
      status: 'confirmed',
      totalPrice,
      depositAmount,
    });

    // Send full reservation details to Formspree
    submitToFormspree({
      form_type: '네일아트샵 실시간 예약 접수',
      reservation_id: created.id,
      customer_name: customerName.trim(),
      customer_phone: customerPhone.trim(),
      reservation_date: selectedDate,
      reservation_time: selectedTime,
      selected_service: selectedService.name,
      service_category: selectedService.category,
      selected_artist: artistObj.name,
      selected_add_ons: selectedAddOns.join(', ') || '없음',
      customer_request_notes: requestNotes.trim() || '요청사항 없음',
      total_estimated_price: `₩${totalPrice.toLocaleString()}`,
      deposit_amount: `₩${depositAmount.toLocaleString()}`,
    });

    setConfirmedReservationId(created.id);
    setStep(5);

    // Launch celebratory confetti
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
      });
    } catch {
      // ignore in iframe if canvas fails
    }
  };

  const handleCopyBookingDetails = () => {
    const artistObj = artists.find((a) => a.id === selectedArtist) || artists[0];
    const text = `[광소장 네일아트샵 예약 내역]
- 예약번호: ${confirmedReservationId}
- 고객명: ${customerName}
- 일시: ${selectedDate} ${selectedTime}
- 시술: ${selectedService?.name}
- 아티스트: ${artistObj.name}
- 예상금액: ₩${totalPrice.toLocaleString()} (예약금 ₩20,000)
- 주소: ${siteConfig.address}`;

    if (navigator.clipboard) {
      navigator.clipboard.writeText(text);
      showToast('예약 정보 복사 완료', '예약 내역이 클립보드에 복사되었습니다.');
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto"
      onClick={closeBooking}
    >
      <div
        className="bg-white rounded-2xl max-w-xl w-full my-auto overflow-hidden shadow-2xl border border-stone-200 animate-in zoom-in-95 duration-150 relative flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Top Header */}
        <div className="p-4 sm:p-5 bg-[#FAF6F2] border-b border-[#EBE2DB] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center shadow-2xs text-[#9E6B5D]">
              <Calendar className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-serif-luxury text-base sm:text-lg font-bold text-stone-900">
                {step === 5 ? '예약 신청 완료' : '온라인 실시간 1:1 예약'}
              </h3>
              <span className="text-[11px] text-stone-500">
                {step === 5 ? '카카오톡 예약 확인서' : `단계 ${step} / 4`}
              </span>
            </div>
          </div>

          <button
            onClick={closeBooking}
            className="p-1.5 rounded-full text-stone-400 hover:text-stone-700 hover:bg-stone-200/60 transition-colors"
            aria-label="닫기"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Multi-step progress bar */}
        {step < 5 && (
          <div className="grid grid-cols-4 bg-stone-100 h-1.5 w-full">
            <div className={`h-full transition-all ${step >= 1 ? 'bg-[#9E6B5D]' : ''}`} />
            <div className={`h-full transition-all ${step >= 2 ? 'bg-[#9E6B5D]' : ''}`} />
            <div className={`h-full transition-all ${step >= 3 ? 'bg-[#9E6B5D]' : ''}`} />
            <div className={`h-full transition-all ${step >= 4 ? 'bg-[#9E6B5D]' : ''}`} />
          </div>
        )}

        {/* Modal Body Container */}
        <div className="p-5 sm:p-6 overflow-y-auto flex-1 space-y-6">
          
          {/* STEP 1: 시술 프로그램 선택 */}
          {step === 1 && (
            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-stone-900 uppercase tracking-wide">
                  1. 원하시는 시술 프로그램을 선택해주세요
                </label>
                <p className="text-xs text-stone-500">
                  모든 시술은 1:1 맞춤형 쉐입 교정 및 기본 위생 케어가 포함되어 있습니다.
                </p>
              </div>

              <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
                {services.map((srv) => (
                  <div
                    key={srv.id}
                    onClick={() => setSelectedService(srv)}
                    className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                      selectedService?.id === srv.id
                        ? 'bg-[#FAF2ED] border-[#9E6B5D] ring-1 ring-[#9E6B5D] shadow-xs'
                        : 'bg-white border-stone-200 hover:bg-stone-50'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-lg overflow-hidden shrink-0 bg-stone-100">
                        <img
                          src={srv.image}
                          alt={srv.name}
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-xs bg-stone-100 text-stone-600">
                            {srv.categoryLabel}
                          </span>
                          <span className="font-serif-luxury font-bold text-sm text-stone-900">
                            {srv.name}
                          </span>
                        </div>
                        <p className="text-[11px] text-stone-500 line-clamp-1 mt-0.5">
                          {srv.description}
                        </p>
                      </div>
                    </div>

                    <div className="text-right shrink-0 ml-2">
                      <div className="font-bold text-sm text-stone-900">
                        ₩{srv.price.toLocaleString()}
                      </div>
                      <span className="text-[10px] text-stone-400">약 {srv.durationMin}분</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* STEP 2: 추가 옵션 & 담당 아티스트 */}
          {step === 2 && (
            <div className="space-y-6">
              {/* Add-ons */}
              <div className="space-y-3">
                <label className="text-xs font-bold text-stone-900 uppercase tracking-wide">
                  2. 추가 옵션 선택 (선택 사항)
                </label>
                <div className="space-y-2">
                  {ADD_ON_OPTIONS.map((opt) => {
                    const isChecked = selectedAddOns.includes(opt.name);
                    return (
                      <div
                        key={opt.id}
                        onClick={() => handleAddOnToggle(opt.name)}
                        className={`p-3 rounded-lg border transition-all cursor-pointer flex items-center justify-between ${
                          isChecked
                            ? 'bg-[#FAF2ED] border-[#9E6B5D]'
                            : 'bg-white border-stone-200 hover:bg-stone-50'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => {}}
                            className="rounded-xs text-[#9E6B5D] focus:ring-0"
                          />
                          <div>
                            <div className="text-xs font-bold text-stone-900">{opt.name}</div>
                            <div className="text-[10px] text-stone-500">{opt.desc}</div>
                          </div>
                        </div>
                        <span className="text-xs font-bold text-stone-800">
                          +₩{opt.price.toLocaleString()}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Artist Select */}
              <div className="space-y-3 pt-2 border-t border-stone-100">
                <label className="text-xs font-bold text-stone-900 uppercase tracking-wide">
                  담당 아티스트 지정
                </label>
                <div className="grid grid-cols-3 gap-2.5">
                  {artists.map((art) => (
                    <div
                      key={art.id}
                      onClick={() => setSelectedArtist(art.id)}
                      className={`p-3 rounded-xl border text-center cursor-pointer transition-all ${
                        selectedArtist === art.id
                          ? 'bg-[#FAF2ED] border-[#9E6B5D] ring-1 ring-[#9E6B5D]'
                          : 'bg-white border-stone-200 hover:bg-stone-50'
                      }`}
                    >
                      <div className="w-10 h-10 rounded-full mx-auto overflow-hidden bg-stone-100 mb-1.5 border border-stone-200">
                        <img
                          src={art.image}
                          alt={art.name}
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                      <div className="font-bold text-xs text-stone-900">{art.name}</div>
                      <div className="text-[10px] text-stone-500 truncate">{art.title}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* STEP 3: 날짜 & 타임슬롯 선택 */}
          {step === 3 && (
            <div className="space-y-5">
              <div className="space-y-2">
                <label className="text-xs font-bold text-stone-900 uppercase tracking-wide">
                  3. 예약 희망 일자 및 시간을 선택해주세요
                </label>
                <input
                  type="date"
                  min={new Date().toISOString().split('T')[0]}
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="w-full p-2.5 text-xs font-semibold border border-stone-300 rounded-md focus:ring-1 focus:ring-[#9E6B5D] focus:outline-hidden"
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-stone-800">예약 가능 시간대</label>
                  <span className="text-[11px] text-emerald-600 font-semibold">● 예약 가능</span>
                </div>
                <div className="grid grid-cols-4 gap-2">
                  {TIME_SLOTS.map((slot) => (
                    <button
                      key={slot}
                      type="button"
                      onClick={() => setSelectedTime(slot)}
                      className={`py-2.5 rounded-lg text-xs font-bold transition-all border ${
                        selectedTime === slot
                          ? 'bg-[#9E6B5D] text-white border-[#9E6B5D] shadow-xs'
                          : 'bg-stone-50 text-stone-800 border-stone-200 hover:bg-stone-100'
                      }`}
                    >
                      {slot}
                    </button>
                  ))}
                </div>
              </div>

              <div className="bg-[#FAF7F5] p-3 rounded-lg border border-[#E8DDD5] text-xs text-stone-600 flex items-start gap-2">
                <Clock className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <span>
                  선택하신 <strong>{selectedDate} {selectedTime}</strong>은 1:1 프라이빗 룸으로 단독 배정됩니다.
                </span>
              </div>
            </div>
          )}

          {/* STEP 4: 고객 정보 입력 & 최종 확인 */}
          {step === 4 && (
            <form onSubmit={handleFinalSubmit} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-stone-900 uppercase tracking-wide">
                  4. 예약자 정보 입력
                </label>
                <p className="text-xs text-stone-500">
                  예약 확정 알림톡 및 주의사항 안내를 위해 정확한 정보를 입력해주세요.
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  고객 성함 *
                </label>
                <input
                  type="text"
                  required
                  placeholder="예: 김민지"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md focus:ring-1 focus:ring-[#9E6B5D] focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  휴대전화 번호 *
                </label>
                <input
                  type="tel"
                  required
                  placeholder="010-0000-0000"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md focus:ring-1 focus:ring-[#9E6B5D] focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  요청사항 또는 디자인 상담 메모 (선택)
                </label>
                <textarea
                  rows={2}
                  placeholder="원하시는 디자인 사진 유무, 손톱 손상 여부, 기타 요청사항"
                  value={requestNotes}
                  onChange={(e) => setRequestNotes(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md focus:ring-1 focus:ring-[#9E6B5D] focus:outline-hidden resize-none"
                />
              </div>

              {/* Order Summary Box */}
              <div className="bg-[#FAF6F2] p-4 rounded-xl border border-[#E8DDD5] space-y-2 text-xs">
                <div className="font-bold text-stone-900 border-b border-stone-200 pb-1.5 flex justify-between">
                  <span>선택 내역 요약</span>
                  <span className="text-[#9E6B5D]">{selectedService?.name}</span>
                </div>
                <div className="flex justify-between text-stone-600">
                  <span>일시:</span>
                  <span className="font-medium text-stone-900">{selectedDate} {selectedTime}</span>
                </div>
                <div className="flex justify-between text-stone-600">
                  <span>담당 아티스트:</span>
                  <span className="font-medium text-stone-900">
                    {artists.find((a) => a.id === selectedArtist)?.name}
                  </span>
                </div>
                {selectedAddOns.length > 0 && (
                  <div className="flex justify-between text-stone-600">
                    <span>추가 옵션:</span>
                    <span className="font-medium text-stone-900">{selectedAddOns.join(', ')}</span>
                  </div>
                )}
                <div className="pt-2 border-t border-stone-200 flex justify-between items-baseline font-bold text-sm text-stone-900">
                  <span>총 예상 결제금액:</span>
                  <span className="text-[#9E6B5D] font-serif-luxury text-lg">
                    ₩{totalPrice.toLocaleString()}
                  </span>
                </div>
                <div className="text-[11px] text-stone-500 pt-1">
                  * 노쇼 방지 예약금 20,000원은 현장 결제 시 차감됩니다.
                </div>
              </div>
            </form>
          )}

          {/* STEP 5: 예약 완료 카카오 알림톡 스타일 카드 */}
          {step === 5 && (
            <div className="space-y-6 py-2">
              <div className="text-center space-y-2">
                <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center shadow-xs">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <h4 className="font-serif-luxury text-xl font-bold text-stone-900">
                  예약 신청이 정상 접수되었습니다!
                </h4>
                <p className="text-xs text-stone-600">
                  광소장 네일아트샵에서 {customerName}님의 시술 일정을 확인 후 카카오톡으로 확정 안내를 발송해 드립니다.
                </p>
              </div>

              {/* Receipt Style Box */}
              <div className="bg-[#FAF7F5] rounded-xl p-5 border border-[#E8DDD5] space-y-3.5 text-xs text-stone-800 shadow-2xs font-sans">
                <div className="flex items-center justify-between border-b border-stone-200 pb-2">
                  <span className="text-stone-500">예약 번호</span>
                  <span className="font-mono font-bold text-stone-900">{confirmedReservationId}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-500">고객 성함</span>
                  <span className="font-bold">{customerName} ({customerPhone})</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-500">예약 일시</span>
                  <span className="font-bold text-[#9E6B5D]">{selectedDate} {selectedTime}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-500">선택 시술</span>
                  <span className="font-bold">{selectedService?.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-500">담당 디자이너</span>
                  <span className="font-bold">
                    {artists.find((a) => a.id === selectedArtist)?.name}
                  </span>
                </div>
                <div className="pt-2 border-t border-stone-200 flex justify-between font-bold text-sm text-stone-900">
                  <span>총 예상 시술비</span>
                  <span>₩{totalPrice.toLocaleString()}</span>
                </div>
                <div className="text-[11px] bg-white p-2.5 rounded-lg border border-stone-200 text-stone-600">
                  📍 <strong>오시는 길:</strong> {siteConfig.address} ({siteConfig.addressDetail})
                </div>
              </div>

              {/* Copy / Actions */}
              <div className="space-y-2">
                <button
                  onClick={handleCopyBookingDetails}
                  className="w-full py-2.5 rounded-md bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>예약 정보 복사하기</span>
                </button>
              </div>
            </div>
          )}

        </div>

        {/* Modal Bottom Action Controls */}
        <div className="p-4 sm:p-5 bg-stone-50 border-t border-stone-200 flex items-center justify-between">
          {step > 1 && step < 5 ? (
            <button
              onClick={() => setStep((prev) => (prev - 1) as any)}
              className="px-4 py-2 text-xs font-semibold text-stone-700 bg-white border border-stone-300 rounded-md hover:bg-stone-100 flex items-center gap-1"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>이전 단계</span>
            </button>
          ) : (
            <div />
          )}

          {step < 4 && (
            <button
              onClick={() => setStep((prev) => (prev + 1) as any)}
              className="px-6 py-2.5 text-xs font-semibold text-white rounded-md flex items-center gap-1 shadow-xs hover:opacity-90 transition-opacity"
              style={{ backgroundColor: siteConfig.theme.primaryColor }}
            >
              <span>다음 단계</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          )}

          {step === 4 && (
            <button
              onClick={handleFinalSubmit}
              className="px-7 py-2.5 text-xs sm:text-sm font-semibold text-white rounded-md shadow-xs hover:opacity-95 transition-all"
              style={{ backgroundColor: siteConfig.theme.primaryColor }}
            >
              예약 확정 신청하기
            </button>
          )}

          {step === 5 && (
            <button
              onClick={closeBooking}
              className="w-full py-3 text-xs sm:text-sm font-semibold text-white rounded-md text-center shadow-xs"
              style={{ backgroundColor: siteConfig.theme.primaryColor }}
            >
              확인 및 창 닫기
            </button>
          )}
        </div>

      </div>
    </div>
  );
};
