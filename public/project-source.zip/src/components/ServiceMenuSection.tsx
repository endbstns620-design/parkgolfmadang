import React, { useState } from 'react';
import { useSalon } from '../context/SalonContext';
import { ServiceCategory, ServiceItem } from '../types';
import {
  Sparkles,
  Clock,
  Check,
  Calendar,
  Layers,
  Eye,
  Footprints,
  Gem,
  HeartHandshake,
} from 'lucide-react';

export const ServiceMenuSection: React.FC = () => {
  const { siteConfig, services, openBooking } = useSalon();
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const categories = [
    { id: 'all', label: '전체 메뉴', icon: Layers },
    { id: 'monthly_art', label: '이달의 아트', icon: Sparkles },
    { id: 'nail_art', label: '핸드 젤네일', icon: Gem },
    { id: 'eyelash', label: '속눈썹 펌/연장', icon: Eye },
    { id: 'pedicure', label: '페디 & 풋스파', icon: Footprints },
    { id: 'special', label: '스페셜 / 웨딩', icon: Sparkles },
    { id: 'care', label: '손톱 건강 케어', icon: HeartHandshake },
  ];

  const filteredServices =
    activeCategory === 'all'
      ? services
      : services.filter((s) => s.category === activeCategory);

  return (
    <section id="services" className="py-16 sm:py-24 bg-[#FAF7F5]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 space-y-3">
          <span
            className="text-xs font-bold uppercase tracking-widest block font-sans"
            style={{ color: siteConfig.theme.primaryColor }}
          >
            Services &amp; Pricing
          </span>
          <h2 className="font-serif-luxury text-3xl sm:text-4xl font-bold text-stone-900">
            시술 프로그램 &amp; 투명한 정찰제 가격표
          </h2>
          <p className="text-sm sm:text-base text-stone-600">
            손상 없는 프리미엄 재료와 1:1 맞춤 상담으로 완성되는 고품격 뷰티 케어입니다.
          </p>
        </div>

        {/* Category Navigation Tabs */}
        <div className="flex items-center justify-start sm:justify-center overflow-x-auto pb-4 gap-2 no-scrollbar mb-10">
          {categories.map((cat) => {
            const Icon = cat.icon;
            const isActive = activeCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`flex items-center gap-1.5 px-4 py-2.5 rounded-full text-xs sm:text-sm font-semibold whitespace-nowrap transition-all duration-200 shadow-2xs ${
                  isActive
                    ? 'text-white shadow-sm'
                    : 'bg-white text-stone-700 hover:bg-[#F2ECE7] border border-[#E8DDD5]'
                }`}
                style={
                  isActive
                    ? { backgroundColor: siteConfig.theme.primaryColor }
                    : {}
                }
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-amber-200' : 'text-stone-500'}`} />
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>

        {/* Service Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {filteredServices.map((service) => (
            <div
              key={service.id}
              className="group bg-white rounded-xl overflow-hidden border border-[#E8DDD5] shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                {/* Image Header */}
                <div className="relative aspect-16/10 overflow-hidden bg-stone-200">
                  <img
                    src={service.image}
                    alt={service.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent" />
                  
                  {/* Category & Badge */}
                  <div className="absolute top-3 left-3 flex flex-wrap gap-1.5">
                    <span className="bg-white/90 backdrop-blur-xs text-stone-800 text-[10px] font-bold px-2 py-0.5 rounded-sm">
                      {service.categoryLabel}
                    </span>
                    {service.badge && (
                      <span
                        className="text-white text-[10px] font-bold px-2 py-0.5 rounded-sm shadow-2xs"
                        style={{ backgroundColor: siteConfig.theme.primaryColor }}
                      >
                        {service.badge}
                      </span>
                    )}
                  </div>

                  {/* Duration pill */}
                  <div className="absolute bottom-3 right-3 bg-black/60 backdrop-blur-xs text-white text-[11px] font-medium px-2 py-0.5 rounded-sm flex items-center gap-1">
                    <Clock className="w-3 h-3 text-stone-300" />
                    <span>약 {service.durationMin}분 소요</span>
                  </div>
                </div>

                {/* Content */}
                <div className="p-5 sm:p-6 space-y-4">
                  <div className="space-y-1.5">
                    <h3 className="font-serif-luxury text-xl font-bold text-stone-900 group-hover:text-[#9E6B5D] transition-colors">
                      {service.name}
                    </h3>
                    <p className="text-xs text-stone-600 leading-relaxed">
                      {service.description}
                    </p>
                  </div>

                  {/* Price Block */}
                  <div className="flex items-baseline gap-2 pt-1 border-t border-stone-100">
                    <span className="font-serif-luxury text-2xl font-bold text-stone-900">
                      ₩{service.price.toLocaleString()}
                    </span>
                    {service.originalPrice && (
                      <span className="text-xs text-stone-400 line-through">
                        ₩{service.originalPrice.toLocaleString()}
                      </span>
                    )}
                    <span className="text-[11px] text-stone-500 font-normal">
                      (VAT 포함 / 1:1 전담)
                    </span>
                  </div>

                  {/* What's Included */}
                  {service.includedOptions && service.includedOptions.length > 0 && (
                    <div className="pt-2 space-y-1.5 bg-[#FAF7F5] p-3 rounded-lg border border-[#EBE2DB]">
                      <div className="text-[11px] font-bold text-[#8C6D62] uppercase tracking-wide">
                        포함 혜택 및 상세 옵션
                      </div>
                      <ul className="space-y-1">
                        {service.includedOptions.map((opt, idx) => (
                          <li key={idx} className="text-xs text-stone-700 flex items-start gap-1.5">
                            <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                            <span>{opt}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>

              {/* Card Action */}
              <div className="p-5 sm:p-6 pt-0">
                <button
                  onClick={() => openBooking(service)}
                  className="w-full py-3 rounded-md text-xs sm:text-sm font-semibold text-white flex items-center justify-center gap-1.5 shadow-xs hover:opacity-90 active:scale-98 transition-all"
                  style={{ backgroundColor: siteConfig.theme.primaryColor }}
                >
                  <Calendar className="w-4 h-4" />
                  <span>이 시술로 예약하기</span>
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Notice Footer inside Menu */}
        <div className="mt-12 text-center text-xs text-stone-500 space-y-1 bg-white p-4 rounded-xl border border-[#E8DDD5] max-w-2xl mx-auto">
          <p className="font-semibold text-stone-700">📌 예약 시 유의사항 안내</p>
          <p>
            • 타샵 젤 제거(쏙오프) 및 특수 파츠 추가는 예약 페이지에서 추가 옵션으로 선택 가능합니다.
          </p>
          <p>
            • 모든 시술은 노쇼 방지를 위해 소정의 예약금(20,000원) 제도로 안전하게 운영됩니다.
          </p>
        </div>

      </div>
    </section>
  );
};
