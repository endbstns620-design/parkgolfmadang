import React, { useState } from 'react';
import { useSalon } from '../context/SalonContext';
import { BlogPost } from '../types';
import {
  Sparkles,
  Calendar,
  Clock,
  ArrowRight,
  X,
  BookOpen,
  Tag,
  User,
  Share2,
} from 'lucide-react';

export const BlogSection: React.FC = () => {
  const { siteConfig, posts, selectedPost, openPostModal, closePostModal, showToast } = useSalon();
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const categories = ['all', '이벤트', '네일아트 팁', '속눈썹 가이드', '살롱 소식'];

  const filteredPosts =
    activeCategory === 'all'
      ? posts
      : posts.filter((p) => p.category === activeCategory);

  const handleShare = (post: BlogPost) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      showToast('링크 복사 완료', '게시글 링크가 클립보드에 복사되었습니다.');
    }
  };

  return (
    <section id="blog" className="py-16 sm:py-24 bg-[#FAF7F5] border-t border-[#EAE3DE]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 space-y-3">
          <span
            className="text-xs font-bold uppercase tracking-widest block font-sans"
            style={{ color: siteConfig.theme.primaryColor }}
          >
            News &amp; Beauty Journal
          </span>
          <h2 className="font-serif-luxury text-3xl sm:text-4xl font-bold text-stone-900">
            광소장 살롱 소식 &amp; 뷰티 가이드
          </h2>
          <p className="text-sm sm:text-base text-stone-600">
            시즌별 이벤트 혜택과 시술 후 유지력을 높여주는 전문가의 뷰티 노하우를 확인하세요.
          </p>
        </div>

        {/* Category Filter Tabs */}
        <div className="flex items-center justify-start sm:justify-center overflow-x-auto pb-4 gap-2 no-scrollbar mb-10">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 py-2 rounded-full text-xs sm:text-sm font-semibold whitespace-nowrap transition-all ${
                activeCategory === cat
                  ? 'text-white shadow-2xs'
                  : 'bg-white text-stone-700 hover:bg-stone-200 border border-[#E8DDD5]'
              }`}
              style={
                activeCategory === cat
                  ? { backgroundColor: siteConfig.theme.primaryColor }
                  : {}
              }
            >
              {cat === 'all' ? '전체 글보기' : cat}
            </button>
          ))}
        </div>

        {/* Posts Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8">
          {filteredPosts.map((post) => (
            <article
              key={post.id}
              onClick={() => openPostModal(post)}
              className="group bg-white rounded-xl overflow-hidden border border-[#E8DDD5] shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col sm:flex-row cursor-pointer"
            >
              {/* Cover Image */}
              <div className="sm:w-2/5 aspect-16/10 sm:aspect-auto relative overflow-hidden bg-stone-100">
                <img
                  src={post.coverImage}
                  alt={post.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-xs text-[#9E6B5D] text-[10px] font-bold px-2 py-0.5 rounded-sm">
                  {post.category}
                </div>
              </div>

              {/* Content Body */}
              <div className="p-6 sm:w-3/5 flex flex-col justify-between space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-3 text-[11px] text-stone-400">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {post.publishDate}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {post.readTime}
                    </span>
                  </div>

                  <h3 className="font-serif-luxury text-lg sm:text-xl font-bold text-stone-900 group-hover:text-[#9E6B5D] transition-colors line-clamp-2">
                    {post.title}
                  </h3>

                  <p className="text-xs text-stone-600 line-clamp-3 leading-relaxed">
                    {post.summary}
                  </p>
                </div>

                <div className="pt-3 border-t border-stone-100 flex items-center justify-between">
                  <div className="flex flex-wrap gap-1">
                    {post.tags.slice(0, 2).map((tag, idx) => (
                      <span
                        key={idx}
                        className="text-[10px] bg-stone-100 text-stone-600 px-2 py-0.5 rounded-sm"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>

                  <span className="text-xs font-semibold text-[#9E6B5D] flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                    자세히 보기 <ArrowRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            </article>
          ))}
        </div>

        {/* Post Reader Modal */}
        {selectedPost && (
          <div
            className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto"
            onClick={closePostModal}
          >
            <div
              className="bg-white rounded-2xl max-w-2xl w-full my-8 overflow-hidden shadow-2xl border border-stone-200 animate-in zoom-in-95 duration-150 relative max-h-[90vh] flex flex-col"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Header with image */}
              <div className="relative h-60 sm:h-72 w-full bg-stone-100 shrink-0">
                <img
                  src={selectedPost.coverImage}
                  alt={selectedPost.title}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />
                
                <button
                  onClick={closePostModal}
                  className="absolute top-4 right-4 p-2 rounded-full bg-black/50 text-white hover:bg-black transition-colors"
                  aria-label="닫기"
                >
                  <X className="w-5 h-5" />
                </button>

                <div className="absolute bottom-4 left-6 right-6 text-white space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="bg-amber-500 text-white text-xs font-bold px-2.5 py-0.5 rounded-sm">
                      {selectedPost.category}
                    </span>
                    <span className="text-xs text-stone-300">
                      {selectedPost.publishDate} • {selectedPost.readTime}
                    </span>
                  </div>
                  <h3 className="font-serif-luxury text-xl sm:text-2xl font-bold leading-snug">
                    {selectedPost.title}
                  </h3>
                </div>
              </div>

              {/* Body Content */}
              <div className="p-6 sm:p-8 overflow-y-auto space-y-6 text-stone-800 leading-relaxed text-sm">
                <div className="bg-[#FAF7F5] p-4 rounded-xl border border-[#E8DDD5] text-xs sm:text-sm font-medium text-[#735A51]">
                  💡 <strong>요약:</strong> {selectedPost.summary}
                </div>

                <div className="whitespace-pre-line space-y-4 text-stone-700 leading-relaxed">
                  {selectedPost.content}
                </div>

                {/* Tags & Author Info */}
                <div className="pt-6 border-t border-stone-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-center gap-2 text-xs text-stone-600">
                    <User className="w-4 h-4 text-stone-400" />
                    <span>작성자: <strong>{selectedPost.author}</strong></span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleShare(selectedPost)}
                      className="px-3 py-1.5 rounded-md bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                      <span>공유하기</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Modal Footer */}
              <div className="p-4 bg-stone-50 border-t border-stone-200 flex justify-end">
                <button
                  onClick={closePostModal}
                  className="px-5 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-md text-xs font-semibold"
                >
                  닫기
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </section>
  );
};
