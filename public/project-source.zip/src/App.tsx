/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { SalonProvider, useSalon } from './context/SalonContext';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { MonthlyArtBanner } from './components/MonthlyArtBanner';
import { ServiceMenuSection } from './components/ServiceMenuSection';
import { GallerySection } from './components/GallerySection';
import { AboutSection } from './components/AboutSection';
import { ReviewSection } from './components/ReviewSection';
import { LocationSection } from './components/LocationSection';
import { Footer } from './components/Footer';
import { BookingModal } from './components/BookingModal';
import { AdminDashboard } from './components/AdminDashboard';
import { FloatingActionBar } from './components/FloatingActionBar';
import { ToastContainer } from './components/ToastContainer';
import { MobileBottomNav } from './components/MobileBottomNav';
import { MobileAppBridgeModal } from './components/MobileAppBridgeModal';

const AppContent: React.FC = () => {
  const { isAdmin, siteConfig } = useSalon();
  const [mobileAppModalOpen, setMobileAppModalOpen] = useState(false);

  // When admin mode is enabled, show ONLY the dedicated Admin Dashboard page
  if (isAdmin) {
    return (
      <div className="min-h-screen bg-[#FAF7F5]">
        <AdminDashboard />
        <ToastContainer />
      </div>
    );
  }

  return (
    <div
      className="min-h-screen flex flex-col selection:bg-[#E8D4C8] selection:text-[#382E2B] pb-16 lg:pb-0"
      style={{ backgroundColor: siteConfig.theme.bgLight }}
    >
      <Navbar onOpenMobileAppModal={() => setMobileAppModalOpen(true)} />

      {/* Main Luxury Customer Website */}
      <main className="flex-grow">
        <HeroSection />
        <MonthlyArtBanner />
        <ServiceMenuSection />
        <GallerySection />
        <AboutSection />
        <ReviewSection />
        <LocationSection />
      </main>

      <Footer />

      {/* Mobile-Native App Bottom Navigation (5 Core Categories + App Actions) */}
      <MobileBottomNav
        onOpenMobileAppModal={() => setMobileAppModalOpen(true)}
      />

      {/* Interactive Modals and Floating Action Widgets */}
      <BookingModal />
      <FloatingActionBar />
      <MobileAppBridgeModal
        isOpen={mobileAppModalOpen}
        onClose={() => setMobileAppModalOpen(false)}
      />
      <ToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <SalonProvider>
      <AppContent />
    </SalonProvider>
  );
}
