import React from 'react';
import { useSalon } from '../context/SalonContext';
import { Calendar, Phone, MessageCircle, Sparkles } from 'lucide-react';

export const FloatingActionBar: React.FC = () => {
  const { siteConfig, openBooking, isAdmin } = useSalon();

  if (isAdmin) return null;

  return (
    <aside
      aria-label="빠른 예약 및 상담 문의"
      className="hidden lg:flex fixed bottom-6 right-8 z-40 items-center justify-end gap-3"
    >
      {/* Floating KakaoTalk Consultation Button */}
      <a
        href={siteConfig.socialLinks.kakaoChannel}
        target="_blank"
        rel="noreferrer"
        className="w-13 h-13 rounded-full bg-[#FEE500] text-[#191919] shadow-xl flex items-center justify-center hover:scale-108 active:scale-95 transition-all border border-amber-300 group"
        title="카카오톡 1:1 빠른 상담"
      >
        <MessageCircle className="w-6 h-6 fill-current group-hover:scale-110 transition-transform" />
      </a>

      {/* Floating Main Booking Button */}
      <button
        onClick={() => openBooking()}
        className="px-6 py-3.5 rounded-full text-white font-bold text-sm shadow-xl flex items-center justify-center gap-2.5 hover:scale-105 active:scale-97 transition-all duration-200"
        style={{
          backgroundColor: siteConfig.theme.primaryColor,
          boxShadow: '0 8px 24px rgba(193, 164, 130, 0.45)',
        }}
      >
        <Sparkles className="w-4 h-4 text-amber-200 animate-pulse" />
        <span>실시간 1:1 예약하기</span>
      </button>
    </aside>
  );
};
