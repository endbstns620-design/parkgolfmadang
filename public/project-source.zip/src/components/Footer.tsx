import React from 'react';
import { useSalon } from '../context/SalonContext';
import { useDownloadHtml } from '../utils/downloadHtml';
import {
  Sparkles,
  Phone,
  MapPin,
  Clock,
  Instagram,
  MessageCircle,
  Settings,
  ShieldCheck,
  Heart,
  Download,
  Smartphone,
} from 'lucide-react';

export const Footer: React.FC = () => {
  const { siteConfig, setIsAdmin, isAdmin, openBooking } = useSalon();
  const { downloadCurrentHtml, isDownloading } = useDownloadHtml();

  const scrollTo = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const yOffset = -80;
      const y = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
      window.scrollTo({ top: y, behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-[#231F1D] text-[#D4CBC4] pt-16 pb-24 border-t border-stone-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-8 pb-12 border-b border-stone-800">
          
          {/* Brand Info (5 cols) */}
          <div className="lg:col-span-5 space-y-4">
            <div className="space-y-1">
              <div className="font-serif-luxury text-2xl sm:text-3xl font-bold tracking-wider text-[#FAF6F2]">
                {siteConfig.brandName}
              </div>
              <div className="text-[10px] tracking-[0.25em] text-[#A69990] uppercase">
                {siteConfig.englishName}
              </div>
            </div>

            <p className="text-xs sm:text-sm text-[#A69990] leading-relaxed max-w-sm">
              {siteConfig.subTagline}
            </p>

            <div className="flex items-center gap-3 pt-2">
              <a
                href={siteConfig.socialLinks.instagram}
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full bg-stone-800 hover:bg-stone-700 text-stone-300 hover:text-white flex items-center justify-center transition-colors"
                aria-label="인스타그램"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href={siteConfig.socialLinks.kakaoChannel}
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full bg-[#FEE500] text-[#191919] hover:opacity-90 flex items-center justify-center transition-opacity"
                aria-label="카카오톡"
              >
                <MessageCircle className="w-4 h-4 fill-current" />
              </a>
              <a
                href={`tel:${siteConfig.phone}`}
                className="w-9 h-9 rounded-full bg-stone-800 hover:bg-stone-700 text-stone-300 hover:text-white flex items-center justify-center transition-colors"
                aria-label="전화"
              >
                <Phone className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Links (3 cols) */}
          <div className="lg:col-span-3 space-y-3">
            <div className="text-xs font-bold uppercase tracking-widest text-[#FAF6F2]">
              메뉴 바로가기
            </div>
            <ul className="space-y-2.5 text-xs text-[#A69990]">
              <li>
                <button
                  onClick={() => scrollTo('about')}
                  className="hover:text-white transition-colors flex items-center gap-1.5"
                >
                  <span className="text-stone-300 font-medium">살롱 소개</span>
                  <span className="text-[10px] text-stone-500 uppercase">About Us</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo('services')}
                  className="hover:text-white transition-colors flex items-center gap-1.5"
                >
                  <span className="text-stone-300 font-medium">시술 &amp; 가격</span>
                  <span className="text-[10px] text-stone-500 uppercase">Our Services</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo('location')}
                  className="hover:text-white transition-colors flex items-center gap-1.5"
                >
                  <span className="text-stone-300 font-medium">오시는 길</span>
                  <span className="text-[10px] text-stone-500 uppercase">Location</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => openBooking()}
                  className="hover:text-amber-300 transition-colors flex items-center gap-1.5 font-semibold text-amber-200"
                >
                  <span>실시간 예약</span>
                  <span className="text-[10px] uppercase">Reservation</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo('reviews')}
                  className="hover:text-white transition-colors flex items-center gap-1.5"
                >
                  <span className="text-stone-300 font-medium">고객 후기</span>
                  <span className="text-[10px] text-stone-500 uppercase">Review</span>
                </button>
              </li>
            </ul>
          </div>

          {/* Salon Details & Contact (4 cols) */}
          <div className="lg:col-span-4 space-y-3">
            <div className="text-xs font-bold uppercase tracking-widest text-[#FAF6F2]">
              살롱 정보 &amp; 예약 문의
            </div>
            <div className="space-y-2 text-xs text-[#A69990]">
              <p>
                <strong className="text-stone-300">대표전화:</strong> {siteConfig.phone}
              </p>
              <p>
                <strong className="text-stone-300">카카오톡:</strong> {siteConfig.kakaoId}
              </p>
              <p>
                <strong className="text-stone-300">주소:</strong> {siteConfig.address}
              </p>
              <p>
                <strong className="text-stone-300">영업시간:</strong> {siteConfig.businessHours.weekday}
              </p>
              <p className="text-stone-400 text-[11px] pt-1">
                사업자등록번호: 211-12-89401 | 대표자: 광소장 | 통신판매신고: 제2026-서울강남-0412호
              </p>
            </div>
          </div>

        </div>

        {/* Bottom copyright & admin shortcut */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-[11px] text-stone-500 gap-4">
          <p>© 2026 {siteConfig.brandName}. All rights reserved. 1:1 Haute Couture Beauty Studio.</p>

          <div className="flex flex-wrap items-center gap-4">
            <button
              onClick={downloadCurrentHtml}
              disabled={isDownloading}
              className="text-amber-300 hover:text-amber-200 flex items-center gap-1 transition-colors font-medium"
            >
              <Download className="w-3 h-3" />
              <span>{isDownloading ? 'HTML 다운로드 중...' : '모바일용 HTML 파일 다운로드'}</span>
            </button>
            <button
              onClick={() => {
                setIsAdmin(!isAdmin);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="hover:text-stone-300 flex items-center gap-1 transition-colors"
            >
              <Settings className="w-3 h-3" />
              <span>{isAdmin ? '관리자 대시보드 닫기' : '관리자 로그인/CMS'}</span>
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};
