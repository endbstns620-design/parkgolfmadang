import React, { useState } from 'react';
import { useSalon } from '../context/SalonContext';
import {
  Calendar,
  Sparkles,
  Phone,
  Settings,
  Menu as MenuIcon,
  X,
  Instagram,
  MessageCircle,
  Clock,
  MapPin,
  ChevronRight,
  Smartphone,
  Info,
  Layers,
  Star,
} from 'lucide-react';

interface NavbarProps {
  onOpenMobileAppModal?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenMobileAppModal }) => {
  const { siteConfig, isAdmin, setIsAdmin, openBooking, showToast } = useSalon();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const copyMobileLink = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      showToast('링크 복사 완료', '모바일 브라우저나 카카오톡에 붙여넣어 바로 접속하세요.', 'success');
    } catch {
      showToast('주소 안내', window.location.href, 'info');
    }
  };

  const scrollTo = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      const yOffset = -80;
      const y = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
      window.scrollTo({ top: y, behavior: 'smooth' });
    }
  };

  const navItems = [
    {
      id: 'about',
      label: '살롱 소개',
      subLabel: 'About Us',
      action: () => scrollTo('about'),
      icon: Info,
    },
    {
      id: 'services',
      label: '시술 & 가격',
      subLabel: 'Our Services',
      action: () => scrollTo('services'),
      icon: Layers,
    },
    {
      id: 'location',
      label: '오시는 길',
      subLabel: 'Location',
      action: () => scrollTo('location'),
      icon: MapPin,
    },
    {
      id: 'reservation',
      label: '실시간 예약',
      subLabel: 'Reservation',
      action: () => openBooking(),
      highlight: true,
      icon: Calendar,
    },
    {
      id: 'reviews',
      label: '고객 후기',
      subLabel: 'Review',
      action: () => scrollTo('reviews'),
      icon: Star,
    },
  ];

  return (
    <header className="sticky top-0 z-40 w-full transition-all duration-300">
      {/* Top Notice Banner */}
      {siteConfig.announcement.enabled && (
        <div
          className="text-xs sm:text-sm py-2 px-4 text-center text-white flex items-center justify-center gap-2 font-medium tracking-wide transition-colors"
          style={{ backgroundColor: siteConfig.theme.primaryColor }}
        >
          <Sparkles className="w-3.5 h-3.5 flex-shrink-0 animate-pulse text-amber-200" />
          <span className="truncate max-w-[85vw]">{siteConfig.announcement.text}</span>
          {siteConfig.announcement.linkText && (
            <button
              onClick={() => openBooking()}
              className="hidden md:inline-flex items-center underline font-semibold text-amber-200 hover:text-white ml-2 text-xs"
            >
              {siteConfig.announcement.linkText} <ChevronRight className="w-3 h-3 ml-0.5" />
            </button>
          )}
        </div>
      )}

      {/* Main Navigation Bar */}
      <nav className="bg-white/95 backdrop-blur-md border-b border-[#EAE3DE] shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            {/* Brand Logo */}
            <div
              onClick={() => scrollTo('hero')}
              className="cursor-pointer flex flex-col items-start select-none group"
            >
              <div className="flex items-center gap-2">
                <span
                  className="font-serif-luxury text-2xl sm:text-3xl font-bold tracking-wider transition-colors"
                  style={{ color: siteConfig.theme.primaryColor }}
                >
                  {siteConfig.brandName}
                </span>
                <span className="text-[10px] uppercase font-bold tracking-widest px-1.5 py-0.5 rounded-xs bg-[#F2EAE5] text-[#8C6D62] hidden sm:inline-block">
                  Atelier
                </span>
              </div>
              <span className="text-[10px] tracking-[0.25em] text-[#8C827D] uppercase font-medium">
                {siteConfig.englishName}
              </span>
            </div>

            {/* Desktop Navigation: 5 Core Categories with Korean + English hierarchy */}
            <div className="hidden lg:flex items-center space-x-1 xl:space-x-2">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={item.action}
                  className={`group px-3.5 py-2 rounded-lg flex flex-col items-center transition-all duration-200 relative ${
                    item.highlight
                      ? 'text-[#8C6D62] font-bold bg-[#FAF6F2] hover:bg-[#F5EFEB]'
                      : 'text-stone-700 hover:text-stone-950 hover:bg-stone-50'
                  }`}
                >
                  <span className="text-[15px] font-semibold tracking-tight transition-colors">
                    {item.label}
                  </span>
                  <span className="text-[9px] tracking-wider uppercase font-medium text-stone-400 group-hover:text-stone-600 transition-colors">
                    {item.subLabel}
                  </span>
                </button>
              ))}
            </div>

            {/* Actions (Mobile App Bridge, Admin Toggle & Booking CTA) */}
            <div className="flex items-center space-x-2 sm:space-x-3">
              {/* Mobile Web Link Share Button */}
              <button
                onClick={copyMobileLink}
                className="hidden md:inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-800 border border-stone-200 transition-all shadow-2xs"
                title="모바일 접속 주소 복사하기"
              >
                <Smartphone className="w-3.5 h-3.5 text-[#8C6D62]" />
                <span>모바일 주소 복사</span>
              </button>

              {/* Admin Mode Toggle Button */}
              <button
                id="admin-mode-toggle-btn"
                onClick={() => setIsAdmin(!isAdmin)}
                className={`px-3 py-2 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 border ${
                  isAdmin
                    ? 'bg-neutral-900 text-white border-neutral-900 shadow-xs'
                    : 'bg-stone-50 text-stone-700 border-stone-200 hover:bg-stone-100'
                }`}
                title="관리자 대시보드 열기/닫기"
              >
                <Settings className={`w-3.5 h-3.5 ${isAdmin ? 'animate-spin' : ''}`} />
                <span>{isAdmin ? '관리자 닫기' : '관리자 모드'}</span>
              </button>

              {/* Instant Booking Button */}
              <button
                id="navbar-booking-btn"
                onClick={() => openBooking()}
                className="hidden sm:inline-flex items-center justify-center px-4.5 py-2.5 text-xs sm:text-sm font-semibold text-white rounded-lg transition-all duration-200 shadow-sm hover:shadow-md active:scale-98 gap-1.5"
                style={{
                  backgroundColor: siteConfig.theme.primaryColor,
                }}
              >
                <Calendar className="w-4 h-4" />
                <span>실시간 예약</span>
              </button>

              {/* Mobile Menu Trigger */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden p-2 rounded-lg text-stone-700 hover:text-stone-900 hover:bg-stone-100 transition-colors"
                aria-label="메뉴 열기"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <MenuIcon className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Dropdown Menu Drawer */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-[#EAE3DE] bg-white px-4 pt-4 pb-6 space-y-4 shadow-xl animate-in slide-in-from-top-2 duration-200">
            <div className="space-y-1.5">
              <div className="text-[11px] font-bold text-stone-400 uppercase tracking-wider px-2">
                살롱 주요 메뉴
              </div>
              <div className="grid grid-cols-1 gap-1.5">
                {navItems.map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.id}
                      onClick={item.action}
                      className={`w-full flex items-center justify-between p-3 rounded-xl transition-all ${
                        item.highlight
                          ? 'bg-[#FAF6F2] text-[#8C6D62] border border-[#EAE3DE] font-bold'
                          : 'hover:bg-stone-50 text-stone-800 font-semibold'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                            item.highlight ? 'bg-white text-[#8C6D62] shadow-2xs' : 'bg-stone-100 text-stone-600'
                          }`}
                        >
                          <Icon className="w-4 h-4" />
                        </div>
                        <div className="text-left">
                          <div className="text-sm">{item.label}</div>
                          <div className="text-[10px] text-stone-400 uppercase tracking-wider">
                            {item.subLabel}
                          </div>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-stone-300" />
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Mobile App Connectivity in Drawer */}
            {onOpenMobileAppModal && (
              <div className="pt-2 border-t border-stone-100">
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenMobileAppModal();
                  }}
                  className="w-full p-3 rounded-xl bg-stone-900 text-white flex items-center justify-between shadow-xs transition-colors hover:bg-stone-800"
                >
                  <div className="flex items-center gap-2.5">
                    <Smartphone className="w-4 h-4 text-amber-300" />
                    <div className="text-left">
                      <div className="text-xs font-bold">모바일 앱 연동 &amp; 홈화면 설치</div>
                      <div className="text-[10px] text-stone-300">내비게이션 &amp; 카톡 상담 1초 연동</div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-white/50" />
                </button>
              </div>
            )}

            <div className="pt-2 border-t border-stone-100 flex flex-col gap-2">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  openBooking();
                }}
                className="w-full py-3.5 text-sm font-semibold text-white rounded-xl text-center flex items-center justify-center gap-2 shadow-sm"
                style={{ backgroundColor: siteConfig.theme.primaryColor }}
              >
                <Calendar className="w-4 h-4" />
                <span>온라인 실시간 예약하기</span>
              </button>

              <div className="flex items-center justify-between text-xs text-stone-500 pt-1 px-1">
                <a
                  href={`tel:${siteConfig.phone}`}
                  className="flex items-center gap-1 text-stone-700 hover:underline"
                >
                  <Phone className="w-3.5 h-3.5" />
                  {siteConfig.phone}
                </a>
                <a
                  href={siteConfig.socialLinks.instagram}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-1 text-stone-700 hover:underline"
                >
                  <Instagram className="w-3.5 h-3.5" />
                  인스타그램
                </a>
              </div>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
};

