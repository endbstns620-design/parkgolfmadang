import React, { useState } from 'react';
import { useSalon } from '../context/SalonContext';
import { useDownloadHtml } from '../utils/downloadHtml';
import {
  Smartphone,
  Download,
  Share2,
  Navigation,
  MessageCircle,
  Instagram,
  Phone,
  CheckCircle2,
  X,
  Copy,
  ExternalLink,
  Sparkles,
  Compass,
  ArrowRight,
  ShieldCheck,
  Calendar,
  FileCode,
  Globe,
} from 'lucide-react';

interface MobileAppBridgeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MobileAppBridgeModal: React.FC<MobileAppBridgeModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { siteConfig, addToast, openBooking } = useSalon();
  const { downloadCurrentHtml, isDownloading } = useDownloadHtml();
  const [activeTab, setActiveTab] = useState<'app_links' | 'pwa_install' | 'download_html' | 'share'>('app_links');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    addToast('샵 바로가기 링크가 클립보드에 복사되었습니다.', 'success');
    setTimeout(() => setCopied(false), 2500);
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: siteConfig.brandName,
          text: `${siteConfig.brandName} - ${siteConfig.subTagline}`,
          url: window.location.href,
        });
      } catch {
        // User cancelled or share failed
      }
    } else {
      handleCopyLink();
    }
  };

  // Quick navigation deep-links for Korea
  const openNaverMapApp = () => {
    const query = encodeURIComponent(`${siteConfig.brandName} ${siteConfig.address}`);
    window.open(`https://map.naver.com/v5/search/${query}`, '_blank');
  };

  const openKakaoMapApp = () => {
    const query = encodeURIComponent(`${siteConfig.brandName}`);
    window.open(`https://map.kakao.com/link/search/${query}`, '_blank');
  };

  const openTMapApp = () => {
    const query = encodeURIComponent(`${siteConfig.brandName}`);
    window.open(`https://tmap.co.kr/tmap2/mobile/route.jsp?name=${query}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="bg-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border border-[#EAE3DE] max-h-[90vh] flex flex-col animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div
          className="p-6 text-white relative flex-shrink-0"
          style={{
            background: `linear-gradient(135deg, #2A2622 0%, #3D3530 100%)`,
          }}
        >
          <button
            onClick={onClose}
            className="absolute top-5 right-5 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white/80 hover:text-white transition-colors"
            aria-label="닫기"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3 mb-2">
            <div
              className="w-10 h-10 rounded-2xl flex items-center justify-center text-white shadow-md"
              style={{ backgroundColor: siteConfig.theme.primaryColor }}
            >
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[11px] uppercase tracking-widest text-[#D4AF37] font-semibold">
                Mobile App Connectivity
              </span>
              <h2 className="font-serif-luxury text-xl sm:text-2xl font-bold text-white">
                모바일 앱 연동 &amp; 바로가기
              </h2>
            </div>
          </div>
          <p className="text-xs text-stone-300 leading-relaxed">
            스마트폰에서 모바일 앱처럼 1초 만에 실행하고, 내비게이션 및 카카오톡 1:1 상담과 연동할 수 있습니다.
          </p>

          {/* Sub Navigation Tabs */}
          <div className="grid grid-cols-4 gap-1 mt-5 bg-white/10 p-1 rounded-xl">
            <button
              onClick={() => setActiveTab('app_links')}
              className={`py-1.5 text-[11px] font-semibold rounded-lg transition-all text-center ${
                activeTab === 'app_links'
                  ? 'bg-white text-stone-900 shadow-xs'
                  : 'text-stone-300 hover:text-white'
              }`}
            >
              앱 바로연동
            </button>
            <button
              onClick={() => setActiveTab('pwa_install')}
              className={`py-1.5 text-[11px] font-semibold rounded-lg transition-all text-center ${
                activeTab === 'pwa_install'
                  ? 'bg-white text-stone-900 shadow-xs'
                  : 'text-stone-300 hover:text-white'
              }`}
            >
              홈화면 추가
            </button>
            <button
              onClick={() => setActiveTab('download_html')}
              className={`py-1.5 text-[11px] font-bold rounded-lg transition-all text-center flex items-center justify-center gap-1 ${
                activeTab === 'download_html'
                  ? 'bg-amber-300 text-stone-950 shadow-xs'
                  : 'text-amber-200 hover:text-white'
              }`}
            >
              <Download className="w-3 h-3" />
              <span>HTML저장</span>
            </button>
            <button
              onClick={() => setActiveTab('share')}
              className={`py-1.5 text-[11px] font-semibold rounded-lg transition-all text-center ${
                activeTab === 'share'
                  ? 'bg-white text-stone-900 shadow-xs'
                  : 'text-stone-300 hover:text-white'
              }`}
            >
              공유&amp;초대
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-grow bg-[#FAF8F5]">
          {/* TAB 1: Smart App Deep Links */}
          {activeTab === 'app_links' && (
            <div className="space-y-5">
              {/* Navigation Apps Grid */}
              <div className="bg-white rounded-2xl p-5 border border-[#EAE3DE] shadow-xs space-y-3">
                <div className="flex items-center gap-2 text-xs font-bold text-stone-900">
                  <Navigation className="w-4 h-4 text-emerald-600" />
                  <span>내비게이션 모바일 앱 1초 길안내</span>
                </div>
                <p className="text-xs text-stone-500">
                  스마트폰에서 터치 시 설치된 내비게이션 앱으로 즉시 경로 안내를 시작합니다.
                </p>
                <div className="grid grid-cols-3 gap-2.5 pt-1">
                  <button
                    onClick={openNaverMapApp}
                    className="p-3 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition-colors"
                  >
                    <div className="w-7 h-7 rounded-full bg-emerald-600 text-white flex items-center justify-center font-black text-xs shadow-xs">
                      N
                    </div>
                    <span>네이버 지도</span>
                  </button>

                  <button
                    onClick={openKakaoMapApp}
                    className="p-3 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition-colors"
                  >
                    <div className="w-7 h-7 rounded-full bg-[#FEE500] text-[#191919] flex items-center justify-center font-black text-xs shadow-xs">
                      K
                    </div>
                    <span>카카오맵</span>
                  </button>

                  <button
                    onClick={openTMapApp}
                    className="p-3 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-900 border border-blue-200 text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition-colors"
                  >
                    <div className="w-7 h-7 rounded-full bg-blue-600 text-white flex items-center justify-center font-black text-xs shadow-xs">
                      T
                    </div>
                    <span>티맵 (TMAP)</span>
                  </button>
                </div>
              </div>

              {/* Communication Apps */}
              <div className="bg-white rounded-2xl p-5 border border-[#EAE3DE] shadow-xs space-y-3">
                <div className="flex items-center gap-2 text-xs font-bold text-stone-900">
                  <MessageCircle className="w-4 h-4 text-amber-500" />
                  <span>소셜 &amp; 1:1 상담 앱 연동</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <a
                    href={siteConfig.socialLinks.kakaoChannel}
                    target="_blank"
                    rel="noreferrer"
                    className="p-3 rounded-xl bg-[#FEE500]/15 hover:bg-[#FEE500]/25 text-[#191919] border border-amber-300 text-xs font-semibold flex items-center gap-3 transition-colors"
                  >
                    <div className="w-8 h-8 rounded-xl bg-[#FEE500] flex items-center justify-center text-[#191919] flex-shrink-0 shadow-xs">
                      <MessageCircle className="w-4 h-4 fill-current" />
                    </div>
                    <div className="text-left">
                      <div className="font-bold">카카오톡 채널</div>
                      <div className="text-[11px] text-stone-600">실시간 1:1 상담</div>
                    </div>
                  </a>

                  <a
                    href={siteConfig.socialLinks.instagram}
                    target="_blank"
                    rel="noreferrer"
                    className="p-3 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-900 border border-rose-200 text-xs font-semibold flex items-center gap-3 transition-colors"
                  >
                    <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 via-rose-500 to-purple-600 text-white flex items-center justify-center flex-shrink-0 shadow-xs">
                      <Instagram className="w-4 h-4" />
                    </div>
                    <div className="text-left">
                      <div className="font-bold">인스타그램 앱</div>
                      <div className="text-[11px] text-stone-600">최신 포트폴리오</div>
                    </div>
                  </a>
                </div>
              </div>

              {/* Fast Calling Action */}
              <a
                href={`tel:${siteConfig.phone}`}
                className="w-full p-4 rounded-2xl bg-[#2A2622] text-white hover:bg-stone-800 transition-colors flex items-center justify-between shadow-md"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-amber-300">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div className="text-left">
                    <div className="text-xs text-stone-300">살롱 직통 전화문의</div>
                    <div className="text-sm font-bold text-white">{siteConfig.phone}</div>
                  </div>
                </div>
                <div className="text-xs text-amber-300 font-semibold flex items-center gap-1">
                  터치하여 바로 통화 <ArrowRight className="w-3.5 h-3.5" />
                </div>
              </a>
            </div>
          )}

          {/* TAB 2: PWA Home Screen Installation Guide */}
          {activeTab === 'pwa_install' && (
            <div className="space-y-4">
              <div className="bg-white rounded-2xl p-5 border border-[#EAE3DE] shadow-xs space-y-4">
                <div className="flex items-center gap-2 text-xs font-bold text-stone-900">
                  <Sparkles className="w-4 h-4 text-amber-500" />
                  <span>스마트폰 홈 화면에 전용 앱으로 추가</span>
                </div>
                <p className="text-xs text-stone-600 leading-relaxed">
                  별도의 앱스토어 다운로드 없이, 스마트폰 홈 화면에 바로가기 아이콘을 추가하여 언제든 실시간 예약 및 포트폴리오를 확인할 수 있습니다.
                </p>

                {/* iOS Guide */}
                <div className="p-4 rounded-xl bg-[#FAF7F5] border border-stone-200 space-y-2">
                  <div className="text-xs font-bold text-stone-900 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-stone-800 inline-block" />
                    <span>아이폰 (Safari 브라우저)</span>
                  </div>
                  <ol className="text-xs text-stone-600 space-y-1.5 list-decimal list-inside pl-1">
                    <li>하단 중앙의 <strong>공유 아이콘 (네모 위 화살표)</strong> 터치</li>
                    <li>메뉴를 내려 <strong>'홈 화면에 추가'</strong> 선택</li>
                    <li>우측 상단 <strong>'추가'</strong>를 누르면 바탕화면 앱 생성 완료</li>
                  </ol>
                </div>

                {/* Android Guide */}
                <div className="p-4 rounded-xl bg-[#FAF7F5] border border-stone-200 space-y-2">
                  <div className="text-xs font-bold text-stone-900 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-600 inline-block" />
                    <span>갤럭시/안드로이드 (Chrome 브라우저)</span>
                  </div>
                  <ol className="text-xs text-stone-600 space-y-1.5 list-decimal list-inside pl-1">
                    <li>우측 상단 <strong>더보기 (점 3개)</strong> 터치</li>
                    <li><strong>'앱 설치'</strong> 또는 <strong>'홈 화면에 추가'</strong> 선택</li>
                    <li>설치 확인 후 바탕화면에서 앱으로 즉시 실행</li>
                  </ol>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: Download Standalone HTML */}
          {activeTab === 'download_html' && (
            <div className="space-y-4">
              <div className="bg-white rounded-2xl p-5 border border-[#EAE3DE] shadow-xs space-y-4">
                <div className="flex items-center gap-2 text-xs font-bold text-stone-900">
                  <FileCode className="w-4 h-4 text-[#8C6D62]" />
                  <span>모바일/오프라인용 HTML 단독 파일 다운로드</span>
                </div>
                <p className="text-xs text-stone-600 leading-relaxed">
                  스마트폰의 '파일' 앱 또는 PC 브라우저에 저장하여 인터넷 연결이나 서버 없이도 언제든 열어볼 수 있는 완전한 단독 HTML 파일로 내려받습니다.
                </p>

                <div className="p-4 rounded-xl bg-amber-50/70 border border-amber-200 text-stone-800 space-y-2">
                  <div className="text-xs font-bold flex items-center gap-1.5 text-amber-900">
                    <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                    <span>모바일에서 열어보는 방법</span>
                  </div>
                  <ul className="text-xs text-stone-700 space-y-1 list-disc list-inside pl-1">
                    <li>다운로드 후 스마트폰 <strong>'내 파일'</strong> 또는 <strong>'파일'</strong> 앱에서 터치</li>
                    <li>Chrome, Safari, 삼성 인터넷 등 기본 브라우저로 바로 실행</li>
                    <li>고객 예약 정보 및 Formspree 문의 연동도 그대로 작동</li>
                  </ul>
                </div>

                <button
                  type="button"
                  onClick={downloadCurrentHtml}
                  disabled={isDownloading}
                  className="w-full py-3.5 px-4 rounded-xl text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md transition-all active:scale-98 disabled:opacity-50"
                  style={{ backgroundColor: siteConfig.theme.primaryColor }}
                >
                  <Download className="w-4 h-4" />
                  <span>{isDownloading ? 'HTML 파일 생성 중...' : '📱 모바일용 HTML 파일 다운로드 (.html)'}</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 4: Share with Friends */}
          {activeTab === 'share' && (
            <div className="space-y-4">
              <div className="bg-white rounded-2xl p-5 border border-[#EAE3DE] shadow-xs space-y-4 text-center">
                <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-800 mx-auto flex items-center justify-center">
                  <Share2 className="w-6 h-6" />
                </div>
                <div className="space-y-1">
                  <h3 className="font-bold text-sm text-stone-900">
                    지인에게 광소장 네일아트샵 추천하기
                  </h3>
                  <p className="text-xs text-stone-500">
                    친구와 동반 예약 시 혜택 및 최신 이달의 아트를 손쉽게 공유해보세요.
                  </p>
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    onClick={handleNativeShare}
                    className="flex-1 py-3 px-4 rounded-xl font-bold text-xs text-white shadow-md flex items-center justify-center gap-2 hover:opacity-95 transition-opacity"
                    style={{ backgroundColor: siteConfig.theme.primaryColor }}
                  >
                    <Share2 className="w-4 h-4" />
                    <span>스마트폰 공유하기</span>
                  </button>
                  <button
                    onClick={handleCopyLink}
                    className="py-3 px-4 rounded-xl border border-stone-300 font-bold text-xs text-stone-700 bg-white hover:bg-stone-50 transition-colors flex items-center justify-center gap-1.5"
                  >
                    {copied ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                    <span>{copied ? '복사됨' : 'URL 복사'}</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer Action */}
        <div className="p-4 bg-white border-t border-stone-200 flex items-center justify-between flex-shrink-0">
          <button
            onClick={() => {
              onClose();
              openBooking();
            }}
            className="w-full py-3 rounded-xl text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-sm transition-transform active:scale-98"
            style={{ backgroundColor: siteConfig.theme.primaryColor }}
          >
            <Calendar className="w-4 h-4" />
            <span>실시간 예약하러 가기</span>
          </button>
        </div>
      </div>
    </div>
  );
};
