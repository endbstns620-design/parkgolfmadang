import React, { useState } from 'react';
import { useSalon } from '../context/SalonContext';
import { submitToFormspree } from '../utils/formspree';
import {
  MapPin,
  Clock,
  Car,
  Train,
  Phone,
  MessageCircle,
  Instagram,
  Copy,
  ExternalLink,
  Calendar,
  Sparkles,
  Send,
  CheckCircle2,
} from 'lucide-react';

export const LocationSection: React.FC = () => {
  const { siteConfig, showToast, openBooking } = useSalon();

  // 1:1 Quick Inquiry Form State
  const [inquiryName, setInquiryName] = useState('');
  const [inquiryPhone, setInquiryPhone] = useState('');
  const [inquiryType, setInquiryType] = useState('시술 상담 및 맞춤 아트');
  const [inquiryMessage, setInquiryMessage] = useState('');
  const [isSubmittingInquiry, setIsSubmittingInquiry] = useState(false);
  const [inquirySubmitted, setInquirySubmitted] = useState(false);

  const handleCopyAddress = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(siteConfig.address);
      showToast('주소 복사 완료', '도로명 주소가 클립보드에 복사되었습니다.');
    }
  };

  const handleInquirySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inquiryName.trim() || !inquiryPhone.trim() || !inquiryMessage.trim()) {
      showToast('입력 확인', '성함, 연락처, 문의 내용을 모두 입력해주세요.', 'error');
      return;
    }

    setIsSubmittingInquiry(true);

    const result = await submitToFormspree({
      form_type: '1:1 빠른 상담 및 시술 문의',
      customer_name: inquiryName.trim(),
      customer_phone: inquiryPhone.trim(),
      inquiry_category: inquiryType,
      message_content: inquiryMessage.trim(),
    });

    setIsSubmittingInquiry(false);

    if (result.ok) {
      setInquirySubmitted(true);
      showToast('문의 접수 완료', '원장님께 문의 내용이 안전하게 전달되었습니다.');
      setInquiryName('');
      setInquiryPhone('');
      setInquiryMessage('');
    } else {
      showToast('전송 안내', '접수 완료되었습니다. 신속히 연락드리겠습니다.');
      setInquirySubmitted(true);
    }
  };

  return (
    <section id="location" className="py-16 sm:py-24 bg-white border-t border-[#EAE3DE]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <span
            className="text-xs font-bold uppercase tracking-widest block font-sans"
            style={{ color: siteConfig.theme.primaryColor }}
          >
            Location &amp; Visiting
          </span>
          <h2 className="font-serif-luxury text-3xl sm:text-4xl font-bold text-stone-900">
            오시는 길 &amp; 살롱 이용 안내
          </h2>
          <p className="text-sm sm:text-base text-stone-600">
            프라이빗하고 쾌적한 1:1 뷰티 힐링 공간, 광소장 네일아트샵으로 오시는 길입니다.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Left Info Columns */}
          <div className="lg:col-span-6 space-y-6">
            
            {/* Address Card */}
            <div className="bg-[#FAF7F5] rounded-2xl p-6 sm:p-7 border border-[#E8DDD5] space-y-4">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-2.5 rounded-lg bg-white shadow-2xs text-[#9E6B5D]">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-serif-luxury text-lg font-bold text-stone-900">
                      살롱 주소 안내
                    </h3>
                    <span className="text-xs text-stone-500">{siteConfig.addressDetail}</span>
                  </div>
                </div>

                <button
                  onClick={handleCopyAddress}
                  className="px-3 py-1.5 rounded-md bg-white hover:bg-stone-100 border border-stone-200 text-stone-700 text-xs font-semibold flex items-center gap-1 transition-colors shadow-2xs"
                  title="주소 복사"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>주소 복사</span>
                </button>
              </div>

              <div className="space-y-1 text-sm font-medium text-stone-800 bg-white p-4 rounded-xl border border-stone-200">
                <p>{siteConfig.address}</p>
              </div>

              {/* Transportation Details */}
              <div className="space-y-3 pt-2 text-xs text-stone-600">
                <div className="flex items-start gap-2.5">
                  <Train className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-stone-800 font-semibold">지하철 이용 시:</strong>{' '}
                    {siteConfig.subwayInfo}
                  </div>
                </div>
                <div className="flex items-start gap-2.5">
                  <Car className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-stone-800 font-semibold">주차 및 발렛:</strong>{' '}
                    {siteConfig.parkingInfo}
                  </div>
                </div>
              </div>
            </div>

            {/* Business Hours Card */}
            <div className="bg-[#FAF7F5] rounded-2xl p-6 sm:p-7 border border-[#E8DDD5] space-y-4">
              <div className="flex items-center gap-2">
                <div className="p-2.5 rounded-lg bg-white shadow-2xs text-[#9E6B5D]">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-serif-luxury text-lg font-bold text-stone-900">
                    영업시간 및 휴무 안내
                  </h3>
                  <span className="text-xs text-stone-500">100% 1:1 사전 예약제 운영</span>
                </div>
              </div>

              <div className="space-y-2.5 text-xs sm:text-sm text-stone-700 divide-y divide-stone-200">
                <div className="flex justify-between items-center pt-2">
                  <span className="font-medium">월요일 ~ 금요일 (평일)</span>
                  <span className="font-bold text-stone-900">{siteConfig.businessHours.weekday}</span>
                </div>
                <div className="flex justify-between items-center pt-2">
                  <span className="font-medium">토요일</span>
                  <span className="font-bold text-stone-900">{siteConfig.businessHours.saturday}</span>
                </div>
                <div className="flex justify-between items-center pt-2">
                  <span className="font-medium">일요일</span>
                  <span className="font-bold text-stone-900">{siteConfig.businessHours.sunday}</span>
                </div>
                <div className="flex justify-between items-center pt-2 text-rose-600 font-semibold">
                  <span>휴무일</span>
                  <span>{siteConfig.businessHours.holidayNotice}</span>
                </div>
              </div>
            </div>

          </div>

          {/* Right Simulated Interactive Map & Quick SNS Card */}
          <div className="lg:col-span-6 flex flex-col justify-between space-y-6">
            
            {/* Map Visual Box */}
            <div className="relative bg-[#ECE5DE] rounded-2xl overflow-hidden border border-[#E0D4C9] shadow-xs aspect-16/10 sm:aspect-16/9 flex flex-col items-center justify-center p-6 text-center group">
              {/* Subtle map pattern background */}
              <div
                className="absolute inset-0 opacity-20"
                style={{
                  backgroundImage: 'radial-gradient(#8C6D62 1px, transparent 1px)',
                  backgroundSize: '16px 16px',
                }}
              />

              {/* Pin */}
              <div className="relative z-10 space-y-3 max-w-sm">
                <div className="w-14 h-14 rounded-full bg-white text-rose-600 shadow-xl mx-auto flex items-center justify-center border-4 border-[#FAF2ED] animate-bounce">
                  <MapPin className="w-7 h-7 fill-rose-500 text-rose-600" />
                </div>
                <div className="bg-white/95 backdrop-blur-sm p-4 rounded-xl shadow-lg border border-stone-200 space-y-1">
                  <div className="font-serif-luxury font-bold text-base text-stone-900">
                    {siteConfig.brandName}
                  </div>
                  <p className="text-xs text-stone-600">{siteConfig.address}</p>
                </div>
              </div>

              {/* Map Action Buttons */}
              <div className="absolute bottom-3 inset-x-4 flex items-center justify-center gap-2 z-10">
                <a
                  href={`https://map.naver.com/v5/search/${encodeURIComponent(siteConfig.brandName)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="px-3 py-1.5 rounded-md bg-[#03C75A] text-white text-xs font-bold flex items-center gap-1 shadow-sm hover:opacity-90 transition-opacity"
                >
                  <span>네이버 지도 열기</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
                <a
                  href={`https://map.kakao.com/link/search/${encodeURIComponent(siteConfig.brandName)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="px-3 py-1.5 rounded-md bg-[#FEE500] text-[#191919] text-xs font-bold flex items-center gap-1 shadow-sm hover:opacity-90 transition-opacity"
                >
                  <span>카카오맵 길찾기</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>

            {/* Quick Contact & SNS Links */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <a
                href={siteConfig.socialLinks.kakaoChannel}
                target="_blank"
                rel="noreferrer"
                className="p-4 rounded-xl bg-[#FEE500]/20 hover:bg-[#FEE500]/35 border border-[#E6D477] transition-all flex items-center gap-3 text-[#3C1E1E]"
              >
                <div className="w-10 h-10 rounded-full bg-[#FEE500] flex items-center justify-center font-bold text-sm shadow-2xs">
                  <MessageCircle className="w-5 h-5 fill-[#3C1E1E] text-[#3C1E1E]" />
                </div>
                <div>
                  <div className="text-xs font-bold">카카오톡 1:1 상담</div>
                  <div className="text-[11px] text-stone-600">ID: {siteConfig.kakaoId}</div>
                </div>
              </a>

              <a
                href={siteConfig.socialLinks.instagram}
                target="_blank"
                rel="noreferrer"
                className="p-4 rounded-xl bg-pink-50 hover:bg-pink-100/70 border border-pink-200 transition-all flex items-center gap-3 text-pink-900"
              >
                <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-amber-500 via-rose-500 to-purple-600 text-white flex items-center justify-center font-bold text-sm shadow-2xs">
                  <Instagram className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-bold">공식 인스타그램</div>
                  <div className="text-[11px] text-stone-600">실시간 신상 아트 업데이트</div>
                </div>
              </a>

              <a
                href={`tel:${siteConfig.phone}`}
                className="p-4 rounded-xl bg-stone-100 hover:bg-stone-200/80 border border-stone-200 transition-all flex items-center gap-3 text-stone-900 sm:col-span-2"
              >
                <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center text-stone-800 shadow-2xs">
                  <Phone className="w-5 h-5" />
                </div>
                <div className="flex-1 flex items-center justify-between">
                  <div>
                    <div className="text-xs font-bold">살롱 유선 전화 상담</div>
                    <div className="text-xs text-stone-600">{siteConfig.phone}</div>
                  </div>
                  <span className="text-xs font-bold text-[#9E6B5D] underline">전화 걸기</span>
                </div>
              </a>
            </div>

          </div>

        </div>

        {/* 1:1 Online Quick Inquiry Form (Formspree Integrated) */}
        <div className="mt-12 bg-linear-to-br from-[#FAF7F5] to-[#F5ECE5] rounded-3xl p-6 sm:p-10 border border-[#E8DDD5] shadow-xs">
          <div className="max-w-3xl mx-auto">
            <div className="text-center space-y-2 mb-8">
              <span
                className="text-xs font-bold uppercase tracking-widest block font-sans"
                style={{ color: siteConfig.theme.primaryColor }}
              >
                Online Consultation &amp; Inquiry
              </span>
              <h3 className="font-serif-luxury text-2xl sm:text-3xl font-bold text-stone-900">
                1:1 맞춤 아트 상담 &amp; 빠른 문의하기
              </h3>
              <p className="text-xs sm:text-sm text-stone-600">
                원하시는 디자인, 손톱 연장, 타샵 쏙오프, 웨딩 네일 등 궁금한 점을 남겨주시면 원장님이 직접 확인 후 빠르게 답변드립니다.
              </p>
            </div>

            {inquirySubmitted ? (
              <div className="bg-white rounded-2xl p-8 text-center space-y-4 border border-stone-200 shadow-sm animate-in fade-in zoom-in-95 duration-200">
                <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <div className="space-y-1">
                  <h4 className="font-serif-luxury text-xl font-bold text-stone-900">
                    문의가 안전하게 접수되었습니다!
                  </h4>
                  <p className="text-xs sm:text-sm text-stone-600">
                    남겨주신 연락처로 담당 아티스트가 확인 후 신속히 안내 연락을 드리겠습니다.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setInquirySubmitted(false)}
                  className="px-5 py-2.5 rounded-xl bg-stone-900 text-white text-xs font-bold hover:bg-stone-800 transition-colors"
                >
                  추가 문의 작성하기
                </button>
              </div>
            ) : (
              <form onSubmit={handleInquirySubmit} className="bg-white rounded-2xl p-6 sm:p-8 border border-stone-200 shadow-xs space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1.5">
                      고객 성함 <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="예: 김민지"
                      value={inquiryName}
                      onChange={(e) => setInquiryName(e.target.value)}
                      className="w-full px-4 py-2.5 text-sm bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-[#8C6D62] focus:outline-hidden transition-all"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1.5">
                      연락처 (휴대폰 번호) <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="예: 010-1234-5678"
                      value={inquiryPhone}
                      onChange={(e) => setInquiryPhone(e.target.value)}
                      className="w-full px-4 py-2.5 text-sm bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-[#8C6D62] focus:outline-hidden transition-all"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1.5">
                    문의 유형
                  </label>
                  <select
                    value={inquiryType}
                    onChange={(e) => setInquiryType(e.target.value)}
                    className="w-full px-4 py-2.5 text-sm bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-[#8C6D62] focus:outline-hidden transition-all"
                  >
                    <option value="시술 상담 및 맞춤 아트">이달의 아트 / 프리미엄 커스텀 디자인 상담</option>
                    <option value="웨딩 & 스페셜 이벤트">웨딩 네일 / 스페셜 패키지 상담</option>
                    <option value="쏙오프 & 문제성 손발톱">타샵 젤 제거 / 손발톱 손상 케어</option>
                    <option value="예약 일정 및 시간 조율">예약 가능 시간 및 일정 조율 문의</option>
                    <option value="기타 살롱 문의">기타 궁금한 점 문의</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1.5">
                    문의 및 요청 내용 <span className="text-rose-500">*</span>
                  </label>
                  <textarea
                    required
                    rows={3}
                    placeholder="희망하시는 시술 종류, 원하시는 예약 시간대, 궁금하신 가격이나 디자인에 대해 편하게 적어주세요."
                    value={inquiryMessage}
                    onChange={(e) => setInquiryMessage(e.target.value)}
                    className="w-full px-4 py-2.5 text-sm bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-[#8C6D62] focus:outline-hidden transition-all resize-none"
                  />
                </div>

                <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-4">
                  <p className="text-[11px] text-stone-500">
                    🔒 남겨주신 정보는 문의 답변 및 예약 상담 목적으로만 안전하게 처리됩니다.
                  </p>
                  <button
                    type="submit"
                    disabled={isSubmittingInquiry}
                    className="w-full sm:w-auto px-6 py-3 rounded-xl text-white font-bold text-sm flex items-center justify-center gap-2 shadow-sm hover:opacity-90 active:scale-98 transition-all disabled:opacity-50 shrink-0"
                    style={{ backgroundColor: siteConfig.theme.primaryColor }}
                  >
                    <Send className="w-4 h-4" />
                    <span>{isSubmittingInquiry ? '문의 전송 중...' : '문의하기 전송'}</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>

      </div>
    </section>
  );
};
