import React from 'react';
import { useSalon } from '../context/SalonContext';
import {
  Sparkles,
  Calendar,
  ShieldCheck,
  Award,
  Heart,
  ChevronDown,
  Clock,
} from 'lucide-react';

export const HeroSection: React.FC = () => {
  const { siteConfig, openBooking } = useSalon();

  const scrollTo = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const yOffset = -80;
      const y = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
      window.scrollTo({ top: y, behavior: 'smooth' });
    }
  };

  return (
    <section id="hero" className="relative overflow-hidden bg-[#FAF6F2] pt-8 pb-16 lg:pt-16 lg:pb-24">
      {/* Decorative subtle background gradient & patterns */}
      <div className="absolute top-0 right-0 -translate-y-12 translate-x-12 w-96 h-96 bg-[#EFE3DB] rounded-full blur-3xl opacity-60 pointer-events-none" />
      <div className="absolute bottom-0 left-0 translate-y-12 -translate-x-12 w-80 h-80 bg-[#F4E6DE] rounded-full blur-3xl opacity-50 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Editorial Copy Column */}
          <div className="lg:col-span-7 space-y-6 sm:space-y-8 text-center lg:text-left">
            
            {/* Top Micro-Tag */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/90 border border-[#E3D6CD] shadow-xs text-xs font-semibold text-[#8C6D62]">
              <span className="w-2 h-2 rounded-full animate-ping" style={{ backgroundColor: siteConfig.theme.primaryColor }} />
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span>Haute Couture Nail &amp; Lash Boutique</span>
            </div>

            {/* Main Headline */}
            <div className="space-y-3">
              <h1 className="font-serif-luxury text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-[#2B2623] leading-[1.15]">
                손끝에 머무는 <br />
                <span
                  className="italic font-normal transition-colors"
                  style={{ color: siteConfig.theme.primaryColor }}
                >
                  우아한 감각
                </span>
                의 예술
              </h1>
              <p className="text-base sm:text-lg text-[#665C56] max-w-2xl mx-auto lg:mx-0 font-normal leading-relaxed">
                {siteConfig.subTagline}
              </p>
            </div>

            {/* Feature Pills */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-2.5 sm:gap-3 text-xs font-medium text-[#5E544E]">
              <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-white/80 border border-[#E8DDD5]">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                5단계 의료용 안심 멸균
              </span>
              <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-white/80 border border-[#E8DDD5]">
                <Award className="w-3.5 h-3.5 text-amber-600" />
                11년 경력 광소장 원장 1:1
              </span>
              <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-white/80 border border-[#E8DDD5]">
                <Heart className="w-3.5 h-3.5 text-rose-500" />
                프리미엄 100% 예약제
              </span>
            </div>

            {/* Call To Action Buttons */}
            <div className="pt-2 flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3.5">
              <button
                id="hero-reservation-cta"
                onClick={() => openBooking()}
                className="w-full sm:w-auto px-7 py-4 rounded-md text-white font-semibold text-sm sm:text-base flex items-center justify-center gap-2.5 shadow-md hover:shadow-lg transition-all duration-200 active:scale-98"
                style={{ backgroundColor: siteConfig.theme.primaryColor }}
              >
                <Calendar className="w-4 h-4" />
                <span>온라인 실시간 예약</span>
              </button>

              <button
                onClick={() => scrollTo('monthly-art')}
                className="w-full sm:w-auto px-6 py-4 rounded-md bg-white hover:bg-[#F9F5F1] text-[#4A413C] font-semibold text-sm sm:text-base border border-[#DECFC6] shadow-xs flex items-center justify-center gap-2 transition-all active:scale-98"
              >
                <Sparkles className="w-4 h-4 text-amber-600" />
                <span>이달의 아트 컬렉션 보기</span>
              </button>
            </div>

            {/* Quick Opening Notice */}
            <div className="flex items-center justify-center lg:justify-start gap-2 text-xs text-[#7A6F68] pt-1">
              <Clock className="w-3.5 h-3.5 text-[#A3978E]" />
              <span>오늘 영업: {siteConfig.businessHours.weekday} (예약 가능)</span>
            </div>

          </div>

          {/* Right Luxury Visual Grid (Boutique Magazine Style) */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              {/* Main Luxury Frame */}
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border-4 border-white aspect-4/5 bg-stone-200">
                <img
                  src={siteConfig.heroImages[0] || 'https://images.unsplash.com/photo-1604654894610-df63bc536371?q=80&w=1200&auto=format&fit=crop'}
                  alt="광소장 네일아트샵 시그니처 젤네일"
                  className="w-full h-full object-cover object-center transform hover:scale-105 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                
                {/* Floating Card inside Photo */}
                <div className="absolute bottom-4 left-4 right-4 p-3.5 rounded-xl bg-white/95 backdrop-blur-sm border border-white/40 shadow-md flex items-center justify-between text-stone-800">
                  <div>
                    <span className="text-[10px] uppercase font-bold tracking-wider text-[#9E6B5D] block">
                      Autumn Signature
                    </span>
                    <span className="font-serif-luxury text-sm sm:text-base font-bold text-stone-900">
                      오로라 시럽 &amp; 수채화 드로잉
                    </span>
                  </div>
                  <button
                    onClick={() => scrollTo('services')}
                    className="text-xs font-semibold text-[#9E6B5D] underline ml-2"
                  >
                    메뉴 보기
                  </button>
                </div>
              </div>

              {/* Secondary Floating Thumbnail */}
              <div className="absolute -bottom-6 -left-6 hidden sm:block w-36 h-36 rounded-xl overflow-hidden shadow-xl border-3 border-white bg-stone-100 z-20">
                <img
                  src={siteConfig.heroImages[1] || 'https://images.unsplash.com/photo-1583001809873-a128495da465?q=80&w=800&auto=format&fit=crop'}
                  alt="속눈썹 펌 시술"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute bottom-0 inset-x-0 bg-black/70 text-white text-[9px] font-bold text-center py-1">
                  블랙틴팅 펌
                </div>
              </div>

              {/* Floating Satisfaction Badge */}
              <div className="absolute -top-4 -right-4 sm:-right-6 bg-white py-2 px-3.5 rounded-xl shadow-lg border border-[#E8DDD5] flex items-center gap-2 z-20">
                <div className="w-8 h-8 rounded-full bg-amber-50 flex items-center justify-center text-amber-600 font-bold text-sm">
                  ★
                </div>
                <div>
                  <div className="text-xs font-bold text-stone-900">4.98 / 5.0</div>
                  <div className="text-[10px] text-stone-500">실제 고객 평점</div>
                </div>
              </div>

            </div>
          </div>

        </div>

        {/* Bottom Trust Indicators Bar */}
        <div className="mt-14 pt-8 border-t border-[#E8DDD5] grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6 text-center">
          <div className="p-3 rounded-lg bg-white/60 border border-[#ECE2DA]">
            <div className="font-serif-luxury text-2xl sm:text-3xl font-bold text-stone-800">11+</div>
            <div className="text-xs text-stone-600 font-medium mt-0.5">광소장 원장 시술 경력 (년)</div>
          </div>
          <div className="p-3 rounded-lg bg-white/60 border border-[#ECE2DA]">
            <div className="font-serif-luxury text-2xl sm:text-3xl font-bold text-stone-800">15,000+</div>
            <div className="text-xs text-stone-600 font-medium mt-0.5">누적 고객 맞춤 시술 건수</div>
          </div>
          <div className="p-3 rounded-lg bg-white/60 border border-[#ECE2DA]">
            <div className="font-serif-luxury text-2xl sm:text-3xl font-bold text-stone-800">99.9%</div>
            <div className="text-xs text-stone-600 font-medium mt-0.5">의료용 5단계 멸균 소독</div>
          </div>
          <div className="p-3 rounded-lg bg-white/60 border border-[#ECE2DA]">
            <div className="font-serif-luxury text-2xl sm:text-3xl font-bold text-stone-800">1:1</div>
            <div className="text-xs text-stone-600 font-medium mt-0.5">프라이빗 맞춤 전담 시술</div>
          </div>
        </div>

      </div>

      {/* Subtle Scroll Indicator */}
      <div className="flex justify-center mt-6">
        <button
          onClick={() => scrollTo('services')}
          className="text-stone-400 hover:text-stone-700 transition-colors animate-bounce p-1"
          aria-label="아래로 스크롤"
        >
          <ChevronDown className="w-5 h-5" />
        </button>
      </div>
    </section>
  );
};
