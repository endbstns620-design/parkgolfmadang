import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  ServiceItem,
  GalleryItem,
  Artist,
  Review,
  BlogPost,
  Reservation,
  SiteConfig,
  ThemeConfig,
  ReservationStatus,
} from '../types';
import {
  INITIAL_SITE_CONFIG,
  INITIAL_SERVICES,
  INITIAL_GALLERY,
  INITIAL_ARTISTS,
  INITIAL_REVIEWS,
  INITIAL_POSTS,
  INITIAL_RESERVATIONS,
  THEME_PALETTES,
} from '../data/initialData';

interface ToastMessage {
  id: string;
  type: 'success' | 'info' | 'error';
  title: string;
  message: string;
}

interface SalonContextType {
  siteConfig: SiteConfig;
  services: ServiceItem[];
  gallery: GalleryItem[];
  artists: Artist[];
  reviews: Review[];
  posts: BlogPost[];
  reservations: Reservation[];
  isAdmin: boolean;
  setIsAdmin: (isAdmin: boolean) => void;
  adminTab: 'dashboard' | 'reservations' | 'posts' | 'services' | 'gallery' | 'theme' | 'seo';
  setAdminTab: (tab: 'dashboard' | 'reservations' | 'posts' | 'services' | 'gallery' | 'theme' | 'seo') => void;
  isBookingOpen: boolean;
  openBooking: (preselectedService?: ServiceItem | null) => void;
  closeBooking: () => void;
  selectedServiceForBooking: ServiceItem | null;
  selectedPost: BlogPost | null;
  openPostModal: (post: BlogPost) => void;
  closePostModal: () => void;
  selectedGalleryItem: GalleryItem | null;
  openGalleryModal: (item: GalleryItem) => void;
  closeGalleryModal: () => void;
  toasts: ToastMessage[];
  showToast: (title: string, message: string, type?: 'success' | 'info' | 'error') => void;
  dismissToast: (id: string) => void;

  // Actions
  updateSiteConfig: (newConfig: Partial<SiteConfig>) => void;
  updateTheme: (theme: Partial<ThemeConfig>) => void;
  selectThemePalette: (paletteId: string) => void;
  
  // Reservations
  addReservation: (reservation: Omit<Reservation, 'id' | 'createdAt'>) => Reservation;
  updateReservationStatus: (id: string, status: ReservationStatus) => void;
  deleteReservation: (id: string) => void;
  
  // Services
  addService: (service: Omit<ServiceItem, 'id'>) => void;
  updateService: (id: string, service: Partial<ServiceItem>) => void;
  deleteService: (id: string) => void;
  
  // Gallery
  addGalleryItem: (item: Omit<GalleryItem, 'id' | 'likes'>) => void;
  updateGalleryItem: (id: string, item: Partial<GalleryItem>) => void;
  deleteGalleryItem: (id: string) => void;
  likeGalleryItem: (id: string) => void;
  
  // Posts
  addPost: (post: Omit<BlogPost, 'id' | 'publishDate'>) => void;
  updatePost: (id: string, post: Partial<BlogPost>) => void;
  deletePost: (id: string) => void;

  // Reviews
  addReview: (review: Omit<Review, 'id' | 'date'>) => void;
  
  // Backup / Reset
  resetToSampleData: () => void;
  exportDataJson: () => void;
  importDataJson: (jsonString: string) => boolean;
}

const SalonContext = createContext<SalonContextType | undefined>(undefined);

const STORAGE_KEYS = {
  CONFIG: 'kwang_salon_config_v1',
  SERVICES: 'kwang_salon_services_v1',
  GALLERY: 'kwang_salon_gallery_v1',
  POSTS: 'kwang_salon_posts_v1',
  RESERVATIONS: 'kwang_salon_reservations_v1',
  REVIEWS: 'kwang_salon_reviews_v1',
};

export const SalonProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [siteConfig, setSiteConfig] = useState<SiteConfig>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CONFIG);
    return saved ? JSON.parse(saved) : INITIAL_SITE_CONFIG;
  });

  const [services, setServices] = useState<ServiceItem[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SERVICES);
    return saved ? JSON.parse(saved) : INITIAL_SERVICES;
  });

  const [gallery, setGallery] = useState<GalleryItem[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.GALLERY);
    return saved ? JSON.parse(saved) : INITIAL_GALLERY;
  });

  const [artists] = useState<Artist[]>(INITIAL_ARTISTS);

  const [reviews, setReviews] = useState<Review[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.REVIEWS);
    return saved ? JSON.parse(saved) : INITIAL_REVIEWS;
  });

  const [posts, setPosts] = useState<BlogPost[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.POSTS);
    return saved ? JSON.parse(saved) : INITIAL_POSTS;
  });

  const [reservations, setReservations] = useState<Reservation[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.RESERVATIONS);
    return saved ? JSON.parse(saved) : INITIAL_RESERVATIONS;
  });

  const [isAdmin, setIsAdmin] = useState(false);
  const [adminTab, setAdminTab] = useState<'dashboard' | 'reservations' | 'posts' | 'services' | 'gallery' | 'theme' | 'seo'>('dashboard');

  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [selectedServiceForBooking, setSelectedServiceForBooking] = useState<ServiceItem | null>(null);

  const [selectedPost, setSelectedPost] = useState<BlogPost | null>(null);
  const [selectedGalleryItem, setSelectedGalleryItem] = useState<GalleryItem | null>(null);

  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // LocalStorage synchronizers
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CONFIG, JSON.stringify(siteConfig));
  }, [siteConfig]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SERVICES, JSON.stringify(services));
  }, [services]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.GALLERY, JSON.stringify(gallery));
  }, [gallery]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.POSTS, JSON.stringify(posts));
  }, [posts]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.RESERVATIONS, JSON.stringify(reservations));
  }, [reservations]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.REVIEWS, JSON.stringify(reviews));
  }, [reviews]);

  const showToast = (title: string, message: string, type: 'success' | 'info' | 'error' = 'success') => {
    const id = Date.now().toString() + Math.random().toString(36).substring(2, 5);
    setToasts((prev) => [...prev, { id, title, message, type }]);
    setTimeout(() => {
      dismissToast(id);
    }, 4000);
  };

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const openBooking = (preselectedService?: ServiceItem | null) => {
    if (preselectedService) {
      setSelectedServiceForBooking(preselectedService);
    }
    setIsBookingOpen(true);
  };

  const closeBooking = () => {
    setIsBookingOpen(false);
    setSelectedServiceForBooking(null);
  };

  const openPostModal = (post: BlogPost) => {
    setSelectedPost(post);
  };

  const closePostModal = () => {
    setSelectedPost(null);
  };

  const openGalleryModal = (item: GalleryItem) => {
    setSelectedGalleryItem(item);
  };

  const closeGalleryModal = () => {
    setSelectedGalleryItem(null);
  };

  // Config & Theme Actions
  const updateSiteConfig = (newConfig: Partial<SiteConfig>) => {
    setSiteConfig((prev) => ({
      ...prev,
      ...newConfig,
    }));
    showToast('설정 저장 완료', '웹사이트 설정 및 콘텐츠가 성공적으로 업데이트되었습니다.');
  };

  const updateTheme = (themeUpdates: Partial<ThemeConfig>) => {
    setSiteConfig((prev) => ({
      ...prev,
      theme: {
        ...prev.theme,
        ...themeUpdates,
      },
    }));
    showToast('테마 적용 완료', '사이트 디자인 스타일이 즉시 변경되었습니다.');
  };

  const selectThemePalette = (paletteId: string) => {
    const target = THEME_PALETTES[paletteId];
    if (target) {
      setSiteConfig((prev) => ({
        ...prev,
        theme: target.theme,
      }));
      showToast('테마 프리셋 적용', `'${target.name}' 팔레트가 적용되었습니다.`);
    }
  };

  // Reservations
  const addReservation = (resData: Omit<Reservation, 'id' | 'createdAt'>) => {
    const newRes: Reservation = {
      ...resData,
      id: 'res-' + Date.now(),
      createdAt: new Date().toISOString(),
    };
    setReservations((prev) => [newRes, ...prev]);
    showToast('예약 접수 완료', `${resData.customerName}님의 시술 예약 신청이 정상 접수되었습니다!`);
    return newRes;
  };

  const updateReservationStatus = (id: string, status: ReservationStatus) => {
    setReservations((prev) =>
      prev.map((r) => (r.id === id ? { ...r, status } : r))
    );
    const labelMap: Record<ReservationStatus, string> = {
      pending: '대기 중',
      confirmed: '예약 확정',
      completed: '시술 완료',
      cancelled: '예약 취소',
    };
    showToast('예약 상태 변경', `예약 상태가 [${labelMap[status]}](으)로 변경되었습니다.`);
  };

  const deleteReservation = (id: string) => {
    setReservations((prev) => prev.filter((r) => r.id !== id));
    showToast('예약 삭제', '선택한 예약 기록이 삭제되었습니다.', 'info');
  };

  // Services
  const addService = (serviceData: Omit<ServiceItem, 'id'>) => {
    const newService: ServiceItem = {
      ...serviceData,
      id: 'srv-' + Date.now(),
    };
    setServices((prev) => [newService, ...prev]);
    showToast('시술 메뉴 추가', `'${serviceData.name}' 시술이 메뉴에 등록되었습니다.`);
  };

  const updateService = (id: string, updates: Partial<ServiceItem>) => {
    setServices((prev) =>
      prev.map((s) => (s.id === id ? { ...s, ...updates } : s))
    );
    showToast('메뉴 수정 완료', '시술 메뉴 정보가 업데이트되었습니다.');
  };

  const deleteService = (id: string) => {
    setServices((prev) => prev.filter((s) => s.id !== id));
    showToast('시술 메뉴 삭제', '시술 항목이 삭제되었습니다.', 'info');
  };

  // Gallery
  const addGalleryItem = (itemData: Omit<GalleryItem, 'id' | 'likes'>) => {
    const newItem: GalleryItem = {
      ...itemData,
      id: 'gal-' + Date.now(),
      likes: Math.floor(Math.random() * 20) + 5,
    };
    setGallery((prev) => [newItem, ...prev]);
    showToast('작품 등록 완료', `'${itemData.title}' 디자인이 갤러리에 추가되었습니다.`);
  };

  const updateGalleryItem = (id: string, updates: Partial<GalleryItem>) => {
    setGallery((prev) =>
      prev.map((g) => (g.id === id ? { ...g, ...updates } : g))
    );
    showToast('갤러리 수정 완료', '작품 정보가 수정되었습니다.');
  };

  const deleteGalleryItem = (id: string) => {
    setGallery((prev) => prev.filter((g) => g.id !== id));
    showToast('작품 삭제', '갤러리 항목이 삭제되었습니다.', 'info');
  };

  const likeGalleryItem = (id: string) => {
    setGallery((prev) =>
      prev.map((g) => (g.id === id ? { ...g, likes: g.likes + 1 } : g))
    );
    showToast('관심 등록', '작품에 좋아요를 남겼습니다!', 'info');
  };

  // Posts
  const addPost = (postData: Omit<BlogPost, 'id' | 'publishDate'>) => {
    const today = new Date().toISOString().split('T')[0];
    const newPost: BlogPost = {
      ...postData,
      id: 'post-' + Date.now(),
      publishDate: today,
    };
    setPosts((prev) => [newPost, ...prev]);
    showToast('게시글 등록 완료', `'${postData.title}' 새 글이 발행되었습니다.`);
  };

  const updatePost = (id: string, updates: Partial<BlogPost>) => {
    setPosts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, ...updates } : p))
    );
    showToast('게시글 수정 완료', '게시글이 성공적으로 수정되었습니다.');
  };

  const deletePost = (id: string) => {
    setPosts((prev) => prev.filter((p) => p.id !== id));
    showToast('게시글 삭제', '게시글이 삭제되었습니다.', 'info');
  };

  // Reviews
  const addReview = (reviewData: Omit<Review, 'id' | 'date'>) => {
    const today = new Date().toISOString().split('T')[0];
    const newReview: Review = {
      ...reviewData,
      id: 'rev-' + Date.now(),
      date: today,
      likes: 1,
    };
    setReviews((prev) => [newReview, ...prev]);
    showToast('후기 등록 완료', '소중한 시술 후기가 등록되었습니다. 감사합니다!');
  };

  // Reset & Export
  const resetToSampleData = () => {
    if (window.confirm('모든 데이터를 초기 샘플 플레이스홀더 상태로 복원하시겠습니까? (작성한 내용이 초기화됩니다)')) {
      localStorage.clear();
      setSiteConfig(INITIAL_SITE_CONFIG);
      setServices(INITIAL_SERVICES);
      setGallery(INITIAL_GALLERY);
      setPosts(INITIAL_POSTS);
      setReservations(INITIAL_RESERVATIONS);
      setReviews(INITIAL_REVIEWS);
      showToast('초기화 완료', '모든 데이터가 기본 샘플 콘텐츠로 복구되었습니다.', 'info');
    }
  };

  const exportDataJson = () => {
    const exportBundle = {
      siteConfig,
      services,
      gallery,
      posts,
      reservations,
      reviews,
      exportedAt: new Date().toISOString(),
    };
    const blob = new Blob([JSON.stringify(exportBundle, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `kwang_nail_backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('백업 파일 다운로드', '전체 웹사이트 데이터가 JSON 파일로 내보내졌습니다.');
  };

  const importDataJson = (jsonString: string): boolean => {
    try {
      const data = JSON.parse(jsonString);
      if (data.siteConfig) setSiteConfig(data.siteConfig);
      if (data.services) setServices(data.services);
      if (data.gallery) setGallery(data.gallery);
      if (data.posts) setPosts(data.posts);
      if (data.reservations) setReservations(data.reservations);
      if (data.reviews) setReviews(data.reviews);
      showToast('데이터 복원 성공', '가져온 백업 데이터가 성공적으로 반영되었습니다.');
      return true;
    } catch {
      showToast('가져오기 실패', '올바른 JSON 백업 파일 형식이 아닙니다.', 'error');
      return false;
    }
  };

  return (
    <SalonContext.Provider
      value={{
        siteConfig,
        services,
        gallery,
        artists,
        reviews,
        posts,
        reservations,
        isAdmin,
        setIsAdmin,
        adminTab,
        setAdminTab,
        isBookingOpen,
        openBooking,
        closeBooking,
        selectedServiceForBooking,
        selectedPost,
        openPostModal,
        closePostModal,
        selectedGalleryItem,
        openGalleryModal,
        closeGalleryModal,
        toasts,
        showToast,
        dismissToast,
        updateSiteConfig,
        updateTheme,
        selectThemePalette,
        addReservation,
        updateReservationStatus,
        deleteReservation,
        addService,
        updateService,
        deleteService,
        addGalleryItem,
        updateGalleryItem,
        deleteGalleryItem,
        likeGalleryItem,
        addPost,
        updatePost,
        deletePost,
        addReview,
        resetToSampleData,
        exportDataJson,
        importDataJson,
      }}
    >
      {children}
    </SalonContext.Provider>
  );
};

export const useSalon = () => {
  const context = useContext(SalonContext);
  if (!context) {
    throw new Error('useSalon must be used within a SalonProvider');
  }
  return context;
};
