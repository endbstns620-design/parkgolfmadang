import React from 'react';
import { useSalon } from '../context/SalonContext';
import { Sparkles, Calendar, ArrowRight, Tag, CheckCircle2 } from 'lucide-react';

export const MonthlyArtBanner: React.FC = () => {
  const { siteConfig, gallery, services, openBooking, openGalleryModal } = useSalon();

  // Find monthly art items from gallery or services
  const monthlyItems = gallery.filter((item) => item.isMonthlyArt || item.category === 'monthly_art');
  const monthlyService = services.find((s) => s.category === 'monthly_art') || services[0];

  return (
    <section id="monthly-art" className="py-16 bg-white border-y border-[#EBE2DB] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#FAF2ED] text-[#9E6B5D] text-xs font-bold uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>Limited Edition Collection</span>
          </div>
          <h2 className="font-serif-luxury text-3xl sm:text-4xl font-bold text-stone-900">
            2026 가을 시즌 이달의 아트
          </h2>
          <p className="text-sm sm:text-base text-stone-600">
            광소장 원장과 수석 아티스트들이 엄선한 최신 트렌드 디자인을 최대 30% 특별 할인가로 만나보세요. (컬러/유무광 변경 무료)
          </p>
        </div>

        {/* Highlight Card Showcase */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
          {monthlyItems.slice(0, 3).map((item) => (
            <div
              key={item.id}
              className="group bg-[#FAF7F5] rounded-xl overflow-hidden border border-[#E8DDD5] shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col"
            >
              {/* Photo Frame */}
              <div
                onClick={() => openGalleryModal(item)}
                className="relative aspect-4/3 overflow-hidden cursor-pointer bg-stone-200"
              >
                <img
                  src={item.imageUrl}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-3 left-3 bg-neutral-900/80 backdrop-blur-xs text-white text-[11px] font-bold px-2.5 py-1 rounded-full flex items-center gap-1">
                  <Tag className="w-3 h-3 text-amber-400" />
                  <span>이달의 특가 ₩{item.price?.toLocaleString()}</span>
                </div>
                <div className="absolute bottom-3 right-3 bg-white/90 backdrop-blur-xs text-stone-800 text-[10px] font-semibold px-2 py-0.5 rounded-sm">
                  디자인: {item.artist}
                </div>
              </div>

              {/* Body */}
              <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                <div>
                  <h3 className="font-serif-luxury text-lg font-bold text-stone-900 group-hover:text-[#9E6B5D] transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-xs text-stone-600 mt-1.5 line-clamp-2 leading-relaxed">
                    {item.description}
                  </p>

                  <div className="flex flex-wrap gap-1.5 mt-3">
                    {item.tags.map((tag, idx) => (
                      <span
                        key={idx}
                        className="text-[10px] bg-white px-2 py-0.5 rounded-sm text-stone-600 border border-stone-200"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Card Action */}
                <div className="pt-2 border-t border-[#E8DDD5] flex items-center justify-between">
                  <div className="text-xs text-stone-500">
                    <span className="line-through text-[11px] mr-1">₩95,000</span>
                    <span className="font-bold text-stone-900 text-sm">₩{item.price?.toLocaleString()}</span>
                  </div>

                  <button
                    onClick={() => openBooking(monthlyService)}
                    className="px-3.5 py-1.5 rounded-md text-xs font-semibold text-white flex items-center gap-1 shadow-xs hover:opacity-90 transition-opacity"
                    style={{ backgroundColor: siteConfig.theme.primaryColor }}
                  >
                    <Calendar className="w-3.5 h-3.5" />
                    <span>이 아트로 예약</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Benefits Banner */}
        <div className="mt-10 p-5 sm:p-6 rounded-xl bg-[#FAF6F2] border border-[#E5D7CC] flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="space-y-1 text-center sm:text-left">
            <div className="font-bold text-sm text-stone-900 flex items-center justify-center sm:justify-start gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>이달의 아트 예약 고객 무료 혜택</span>
            </div>
            <p className="text-xs text-stone-600">
              손톱 쉐입 교정 + 프리미엄 빌더젤 오버레이 코팅 + 유/무광 탑 변경 + 컬러 톤 변경 추가금 없음!
            </p>
          </div>

          <button
            onClick={() => openBooking(monthlyService)}
            className="px-5 py-2.5 rounded-md text-xs sm:text-sm font-semibold text-white whitespace-nowrap flex items-center gap-1.5 shadow-xs hover:opacity-95 transition-all"
            style={{ backgroundColor: siteConfig.theme.primaryColor }}
          >
            <span>이달의 아트 실시간 예약</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </section>
  );
};
