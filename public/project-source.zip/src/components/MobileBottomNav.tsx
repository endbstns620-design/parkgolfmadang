import React, { useState, useEffect } from 'react';
import { useSalon } from '../context/SalonContext';
import {
  Sparkles,
  Info,
  Calendar,
  Star,
  MapPin,
  MessageCircle,
  Phone,
  Smartphone,
  Layers,
  ChevronUp,
} from 'lucide-react';

interface MobileBottomNavProps {
  onOpenMobileAppModal: () => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  onOpenMobileAppModal,
}) => {
  const { siteConfig, openBooking, isAdmin } = useSalon();
  const [activeTab, setActiveTab] = useState<string>('home');
  const [quickMenuOpen, setQuickMenuOpen] = useState(false);

  // Active section tracking on scroll
  useEffect(() => {
    const handleScroll = () => {
      const scrollPos = window.scrollY + 200;
      const sections = [
        { id: 'about', tab: 'about' },
        { id: 'services', tab: 'services' },
        { id: 'reviews', tab: 'reviews' },
        { id: 'location', tab: 'location' },
      ];

      for (const section of sections) {
        const el = document.getElementById(section.id);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPos >= top && scrollPos < top + height) {
            setActiveTab(section.tab);
            return;
          }
        }
      }
      if (window.scrollY < 300) {
        setActiveTab('home');
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollTo = (id: string, tabName: string) => {
    setActiveTab(tabName);
    setQuickMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      const yOffset = -75;
      const y = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
      window.scrollTo({ top: y, behavior: 'smooth' });
    }
  };

  if (isAdmin) return null;

  return (
    <>
      {/* Quick Speed Dial Menu for Phone / Kakao / App connectivity */}
      {quickMenuOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/40 backdrop-blur-2xs lg:hidden animate-in fade-in duration-150"
          onClick={() => setQuickMenuOpen(false)}
        >
          <div
            className="absolute bottom-20 right-4 bg-white rounded-2xl shadow-2xl border border-[#EAE3DE] p-3 space-y-2 w-56 animate-in slide-in-from-bottom-5 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="text-[11px] font-bold uppercase tracking-wider text-stone-400 px-2 py-1">
              빠른 모바일 연동
            </div>

            <a
              href={`tel:${siteConfig.phone}`}
              className="flex items-center gap-2.5 p-2.5 rounded-xl hover:bg-stone-50 text-stone-800 text-xs font-semibold transition-colors"
            >
              <div className="w-7 h-7 rounded-lg bg-stone-100 flex items-center justify-center text-stone-700">
                <Phone className="w-3.5 h-3.5" />
              </div>
              <span>전화 상담하기</span>
            </a>

            <a
              href={siteConfig.socialLinks.kakaoChannel}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-2.5 p-2.5 rounded-xl hover:bg-amber-50 text-amber-900 text-xs font-semibold transition-colors"
            >
              <div className="w-7 h-7 rounded-lg bg-[#FEE500] flex items-center justify-center text-[#191919]">
                <MessageCircle className="w-3.5 h-3.5 fill-current" />
              </div>
              <span>카카오톡 1:1 빠른상담</span>
            </a>

            <button
              onClick={() => {
                setQuickMenuOpen(false);
                onOpenMobileAppModal();
              }}
              className="w-full flex items-center gap-2.5 p-2.5 rounded-xl bg-stone-900 text-white text-xs font-semibold transition-colors"
            >
              <div className="w-7 h-7 rounded-lg bg-white/20 flex items-center justify-center text-amber-300">
                <Smartphone className="w-3.5 h-3.5" />
              </div>
              <span>모바일 앱 바로연동 안내</span>
            </button>
          </div>
        </div>
      )}

      {/* Main Native Mobile Bottom Bar (iOS/Android Style) */}
      <nav
        aria-label="모바일 하단 네비게이션"
        className="lg:hidden fixed bottom-0 inset-x-0 z-40 bg-white/95 backdrop-blur-md border-t border-[#EAE3DE] shadow-[0_-4px_20px_rgba(0,0,0,0.06)] pb-[env(safe-area-inset-bottom)]"
      >
        <div className="grid grid-cols-5 items-center h-16 max-w-md mx-auto px-1 relative">
          
          {/* 1. About Us (살롱 소개) */}
          <button
            onClick={() => scrollTo('about', 'about')}
            className={`flex flex-col items-center justify-center h-full transition-colors relative ${
              activeTab === 'about' ? 'text-[#8C6D62] font-bold' : 'text-stone-500 hover:text-stone-800'
            }`}
          >
            <Info className="w-5 h-5 mb-0.5" />
            <span className="text-[10px] tracking-tight">살롱 소개</span>
            <span className="text-[8px] tracking-tighter opacity-60 uppercase font-medium">About</span>
            {activeTab === 'about' && (
              <span
                className="absolute top-1 w-1 h-1 rounded-full"
                style={{ backgroundColor: siteConfig.theme.primaryColor }}
              />
            )}
          </button>

          {/* 2. Our Services (시술 & 가격) */}
          <button
            onClick={() => scrollTo('services', 'services')}
            className={`flex flex-col items-center justify-center h-full transition-colors relative ${
              activeTab === 'services' ? 'text-[#8C6D62] font-bold' : 'text-stone-500 hover:text-stone-800'
            }`}
          >
            <Layers className="w-5 h-5 mb-0.5" />
            <span className="text-[10px] tracking-tight">시술 &amp; 가격</span>
            <span className="text-[8px] tracking-tighter opacity-60 uppercase font-medium">Services</span>
            {activeTab === 'services' && (
              <span
                className="absolute top-1 w-1 h-1 rounded-full"
                style={{ backgroundColor: siteConfig.theme.primaryColor }}
              />
            )}
          </button>

          {/* 3. Reservation (실시간 예약) - Highlighted Floating Action Button */}
          <div className="flex flex-col items-center justify-center -mt-5">
            <button
              onClick={() => openBooking()}
              className="w-13 h-13 rounded-full text-white shadow-lg flex flex-col items-center justify-center transition-transform active:scale-95 border-2 border-white"
              style={{
                backgroundColor: siteConfig.theme.primaryColor,
                boxShadow: `0 6px 18px rgba(193, 164, 130, 0.45)`,
              }}
              aria-label="실시간 예약하기"
            >
              <Calendar className="w-5 h-5" />
              <span className="text-[9px] font-black tracking-tighter mt-0.5">예약</span>
            </button>
            <span className="text-[8px] font-bold text-stone-700 tracking-tight mt-0.5">
              실시간 예약
            </span>
          </div>

          {/* 4. Review (고객 후기) */}
          <button
            onClick={() => scrollTo('reviews', 'reviews')}
            className={`flex flex-col items-center justify-center h-full transition-colors relative ${
              activeTab === 'reviews' ? 'text-[#8C6D62] font-bold' : 'text-stone-500 hover:text-stone-800'
            }`}
          >
            <Star className="w-5 h-5 mb-0.5" />
            <span className="text-[10px] tracking-tight">고객 후기</span>
            <span className="text-[8px] tracking-tighter opacity-60 uppercase font-medium">Review</span>
            {activeTab === 'reviews' && (
              <span
                className="absolute top-1 w-1 h-1 rounded-full"
                style={{ backgroundColor: siteConfig.theme.primaryColor }}
              />
            )}
          </button>

          {/* 5. Location (오시는 길) */}
          <button
            onClick={() => scrollTo('location', 'location')}
            className={`flex flex-col items-center justify-center h-full transition-colors relative ${
              activeTab === 'location' ? 'text-[#8C6D62] font-bold' : 'text-stone-500 hover:text-stone-800'
            }`}
          >
            <MapPin className="w-5 h-5 mb-0.5" />
            <span className="text-[10px] tracking-tight">오시는 길</span>
            <span className="text-[8px] tracking-tighter opacity-60 uppercase font-medium">Location</span>
            {activeTab === 'location' && (
              <span
                className="absolute top-1 w-1 h-1 rounded-full"
                style={{ backgroundColor: siteConfig.theme.primaryColor }}
              />
            )}
          </button>
        </div>

        {/* Small floating quick action button to open phone/Kakao/App modal */}
        <div className="absolute right-3 -top-12">
          <button
            onClick={() => setQuickMenuOpen(!quickMenuOpen)}
            className="w-10 h-10 rounded-full bg-[#2A2622] text-amber-300 shadow-md flex items-center justify-center text-xs font-bold border border-white/20 active:scale-95 transition-transform"
            title="모바일 빠른 연동"
            aria-label="빠른 연동 메뉴"
          >
            <ChevronUp className={`w-4 h-4 transition-transform ${quickMenuOpen ? 'rotate-180' : ''}`} />
          </button>
        </div>
      </nav>
    </>
  );
};
