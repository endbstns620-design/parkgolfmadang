export type ServiceCategory = 'monthly_art' | 'nail_art' | 'eyelash' | 'pedicure' | 'care' | 'special';

export interface ServiceItem {
  id: string;
  name: string;
  category: ServiceCategory;
  categoryLabel: string;
  price: number;
  originalPrice?: number;
  durationMin: number;
  description: string;
  badge?: string;
  image: string;
  includedOptions: string[];
  popular?: boolean;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: ServiceCategory;
  categoryLabel: string;
  imageUrl: string;
  tags: string[];
  price?: number;
  artist: string;
  likes: number;
  description: string;
  isMonthlyArt?: boolean;
  date: string;
}

export interface Artist {
  id: string;
  name: string;
  role: string;
  title: string;
  experienceYears: number;
  bio: string;
  specialties: string[];
  image: string;
  instagram: string;
  certifications: string[];
}

export interface Review {
  id: string;
  author: string;
  rating: number;
  date: string;
  serviceName: string;
  comment: string;
  photos?: string[];
  verified: boolean;
  staffName: string;
  likes?: number;
}

export interface BlogPost {
  id: string;
  title: string;
  category: '이벤트' | '네일아트 팁' | '속눈썹 가이드' | '살롱 소식';
  summary: string;
  content: string;
  coverImage: string;
  author: string;
  publishDate: string;
  readTime: string;
  isFeatured?: boolean;
  tags: string[];
}

export type ReservationStatus = 'pending' | 'confirmed' | 'completed' | 'cancelled';

export interface Reservation {
  id: string;
  customerName: string;
  phone: string;
  date: string;
  time: string;
  artistId: string;
  artistName: string;
  serviceId: string;
  serviceName: string;
  category: ServiceCategory;
  addOns: string[];
  requestNotes: string;
  status: ReservationStatus;
  totalPrice: number;
  depositAmount: number;
  createdAt: string;
}

export type ThemePaletteId = 'immersive_ui' | 'champagne_rose' | 'warm_nude' | 'modern_charcoal' | 'romantic_pink' | 'sage_elegance';

export interface ThemeConfig {
  paletteId: ThemePaletteId;
  primaryColor: string;      // e.g. #9E7265
  primaryHover: string;      // e.g. #855C50
  accentColor: string;       // e.g. #D4AF37
  bgLight: string;           // e.g. #FAF7F5
  cardBg: string;            // e.g. #FFFFFF
  fontFamily: 'serif' | 'sans' | 'mixed';
  borderRadius: 'sm' | 'md' | 'lg' | 'full';
}

export interface SiteConfig {
  brandName: string;
  englishName: string;
  tagline: string;
  subTagline: string;
  phone: string;
  kakaoId: string;
  address: string;
  addressDetail: string;
  subwayInfo: string;
  parkingInfo: string;
  businessHours: {
    weekday: string;
    saturday: string;
    sunday: string;
    holidayNotice: string;
  };
  announcement: {
    enabled: boolean;
    text: string;
    linkText?: string;
  };
  socialLinks: {
    instagram: string;
    kakaoChannel: string;
    naverBooking: string;
    youtube: string;
    phone: string;
  };
  seo: {
    title: string;
    description: string;
    keywords: string;
    ogImage: string;
    author: string;
    siteUrl: string;
  };
  theme: ThemeConfig;
  heroImages: string[];
  noticeBannerText: string;
}
