import React, { useState } from 'react';
import { useSalon } from '../context/SalonContext';
import { useDownloadHtml } from '../utils/downloadHtml';
import {
  Calendar,
  FileText,
  Gem,
  Image,
  Palette,
  Globe,
  Database,
  Plus,
  Trash2,
  Edit,
  Save,
  CheckCircle,
  X,
  Sparkles,
  ExternalLink,
  Search,
  RefreshCw,
  Download,
  Upload,
  ArrowRight,
  Eye,
  Sliders,
  Phone,
  Instagram,
  MessageCircle,
} from 'lucide-react';
import { THEME_PALETTES } from '../data/initialData';
import { ReservationStatus, ServiceCategory, ServiceItem, BlogPost, GalleryItem } from '../types';

export const AdminDashboard: React.FC = () => {
  const {
    siteConfig,
    services,
    gallery,
    artists,
    posts,
    reservations,
    adminTab,
    setAdminTab,
    setIsAdmin,
    updateSiteConfig,
    updateTheme,
    selectThemePalette,
    updateReservationStatus,
    deleteReservation,
    addReservation,
    addService,
    updateService,
    deleteService,
    addGalleryItem,
    updateGalleryItem,
    deleteGalleryItem,
    addPost,
    updatePost,
    deletePost,
    resetToSampleData,
    exportDataJson,
    importDataJson,
    showToast,
  } = useSalon();
  const { downloadCurrentHtml, isDownloading } = useDownloadHtml();

  // Local CMS States
  const [resSearch, setResSearch] = useState('');
  const [resStatusFilter, setResStatusFilter] = useState<string>('all');

  // New Post Form State
  const [isAddingPost, setIsAddingPost] = useState(false);
  const [postTitle, setPostTitle] = useState('');
  const [postCategory, setPostCategory] = useState<'이벤트' | '네일아트 팁' | '속눈썹 가이드' | '살롱 소식'>('이벤트');
  const [postSummary, setPostSummary] = useState('');
  const [postContent, setPostContent] = useState('');
  const [postCoverImage, setPostCoverImage] = useState('https://images.unsplash.com/photo-1632345031435-8727f6897d53?q=80&w=1000&auto=format&fit=crop');
  const [postAuthor, setPostAuthor] = useState('광소장 원장');
  const [postTags, setPostTags] = useState('이달의아트, 프로모션');
  const [editingPostId, setEditingPostId] = useState<string | null>(null);

  // New Service Form State
  const [isAddingService, setIsAddingService] = useState(false);
  const [srvName, setSrvName] = useState('');
  const [srvCategory, setSrvCategory] = useState<ServiceCategory>('nail_art');
  const [srvPrice, setSrvPrice] = useState(70000);
  const [srvOriginalPrice, setSrvOriginalPrice] = useState<number | undefined>(85000);
  const [srvDuration, setSrvDuration] = useState(60);
  const [srvDesc, setSrvDesc] = useState('');
  const [srvBadge, setSrvBadge] = useState('추천');
  const [srvImage, setSrvImage] = useState('https://images.unsplash.com/photo-1604654894610-df63bc536371?q=80&w=800&auto=format&fit=crop');
  const [srvOptions, setSrvOptions] = useState('기본 큐티클 케어, 오버레이 코팅');
  const [editingSrvId, setEditingSrvId] = useState<string | null>(null);

  // New Gallery Item Form State
  const [isAddingGallery, setIsAddingGallery] = useState(false);
  const [galTitle, setGalTitle] = useState('');
  const [galCategory, setGalCategory] = useState<ServiceCategory>('monthly_art');
  const [galImage, setGalImage] = useState('https://images.unsplash.com/photo-1519014816548-bf5fe059798b?q=80&w=800&auto=format&fit=crop');
  const [galPrice, setGalPrice] = useState(69000);
  const [galArtist, setGalArtist] = useState('광소장 원장');
  const [galDesc, setGalDesc] = useState('');
  const [galTags, setGalTags] = useState('시럽네일, 가을신상');
  const [galIsMonthly, setGalIsMonthly] = useState(true);

  // Custom Site Branding State
  const [brandForm, setBrandForm] = useState({
    brandName: siteConfig.brandName,
    englishName: siteConfig.englishName,
    tagline: siteConfig.tagline,
    subTagline: siteConfig.subTagline,
    phone: siteConfig.phone,
    kakaoId: siteConfig.kakaoId,
    address: siteConfig.address,
    addressDetail: siteConfig.addressDetail,
    subwayInfo: siteConfig.subwayInfo,
    parkingInfo: siteConfig.parkingInfo,
    weekdayHours: siteConfig.businessHours.weekday,
    saturdayHours: siteConfig.businessHours.saturday,
    sundayHours: siteConfig.businessHours.sunday,
    holidayNotice: siteConfig.businessHours.holidayNotice,
    announcementEnabled: siteConfig.announcement.enabled,
    announcementText: siteConfig.announcement.text,
  });

  // SEO Form State
  const [seoForm, setSeoForm] = useState({
    title: siteConfig.seo.title,
    description: siteConfig.seo.description,
    keywords: siteConfig.seo.keywords,
    ogImage: siteConfig.seo.ogImage,
    instagram: siteConfig.socialLinks.instagram,
    kakaoChannel: siteConfig.socialLinks.kakaoChannel,
    naverBooking: siteConfig.socialLinks.naverBooking,
    youtube: siteConfig.socialLinks.youtube,
  });

  // Handle Post Save
  const handleSavePost = (e: React.FormEvent) => {
    e.preventDefault();
    const tagArray = postTags.split(',').map((t) => t.trim()).filter(Boolean);

    if (editingPostId) {
      updatePost(editingPostId, {
        title: postTitle,
        category: postCategory,
        summary: postSummary,
        content: postContent,
        coverImage: postCoverImage,
        author: postAuthor,
        tags: tagArray,
      });
      setEditingPostId(null);
    } else {
      addPost({
        title: postTitle,
        category: postCategory,
        summary: postSummary,
        content: postContent,
        coverImage: postCoverImage,
        author: postAuthor,
        readTime: '3분 읽기',
        tags: tagArray,
      });
    }

    setIsAddingPost(false);
    setPostTitle('');
    setPostSummary('');
    setPostContent('');
  };

  // Handle Service Save
  const handleSaveService = (e: React.FormEvent) => {
    e.preventDefault();
    const catLabels: Record<ServiceCategory, string> = {
      monthly_art: '이달의 아트',
      nail_art: '핸드 젤네일',
      eyelash: '속눈썹 시술',
      pedicure: '페디 & 풋스파',
      special: '스페셜/웨딩',
      care: '손톱 케어',
    };

    const optArray = srvOptions.split(',').map((o) => o.trim()).filter(Boolean);

    if (editingSrvId) {
      updateService(editingSrvId, {
        name: srvName,
        category: srvCategory,
        categoryLabel: catLabels[srvCategory],
        price: Number(srvPrice),
        originalPrice: srvOriginalPrice ? Number(srvOriginalPrice) : undefined,
        durationMin: Number(srvDuration),
        description: srvDesc,
        badge: srvBadge,
        image: srvImage,
        includedOptions: optArray,
      });
      setEditingSrvId(null);
    } else {
      addService({
        name: srvName,
        category: srvCategory,
        categoryLabel: catLabels[srvCategory],
        price: Number(srvPrice),
        originalPrice: srvOriginalPrice ? Number(srvOriginalPrice) : undefined,
        durationMin: Number(srvDuration),
        description: srvDesc,
        badge: srvBadge,
        image: srvImage,
        includedOptions: optArray,
      });
    }

    setIsAddingService(false);
    setSrvName('');
    setSrvDesc('');
  };

  // Handle Gallery Save
  const handleSaveGallery = (e: React.FormEvent) => {
    e.preventDefault();
    const catLabels: Record<ServiceCategory, string> = {
      monthly_art: '이달의 아트',
      nail_art: '핸드 젤네일',
      eyelash: '속눈썹 시술',
      pedicure: '페디 & 풋스파',
      special: '스페셜/웨딩',
      care: '손톱 케어',
    };

    const tagArray = galTags.split(',').map((t) => t.trim()).filter(Boolean);

    addGalleryItem({
      title: galTitle,
      category: galCategory,
      categoryLabel: catLabels[galCategory],
      imageUrl: galImage,
      tags: tagArray,
      price: Number(galPrice),
      artist: galArtist,
      description: galDesc,
      isMonthlyArt: galIsMonthly,
      date: new Date().toISOString().slice(0, 7),
    });

    setIsAddingGallery(false);
    setGalTitle('');
    setGalDesc('');
  };

  // Handle Brand Text Updates
  const handleSaveBranding = (e: React.FormEvent) => {
    e.preventDefault();
    updateSiteConfig({
      brandName: brandForm.brandName,
      englishName: brandForm.englishName,
      tagline: brandForm.tagline,
      subTagline: brandForm.subTagline,
      phone: brandForm.phone,
      kakaoId: brandForm.kakaoId,
      address: brandForm.address,
      addressDetail: brandForm.addressDetail,
      subwayInfo: brandForm.subwayInfo,
      parkingInfo: brandForm.parkingInfo,
      businessHours: {
        weekday: brandForm.weekdayHours,
        saturday: brandForm.saturdayHours,
        sunday: brandForm.sundayHours,
        holidayNotice: brandForm.holidayNotice,
      },
      announcement: {
        enabled: brandForm.announcementEnabled,
        text: brandForm.announcementText,
        linkText: '이벤트 확인하기',
      },
    });
  };

  // Handle SEO & Social Save
  const handleSaveSeo = (e: React.FormEvent) => {
    e.preventDefault();
    updateSiteConfig({
      seo: {
        ...siteConfig.seo,
        title: seoForm.title,
        description: seoForm.description,
        keywords: seoForm.keywords,
        ogImage: seoForm.ogImage,
      },
      socialLinks: {
        ...siteConfig.socialLinks,
        instagram: seoForm.instagram,
        kakaoChannel: seoForm.kakaoChannel,
        naverBooking: seoForm.naverBooking,
        youtube: seoForm.youtube,
      },
    });
  };

  // Filtered reservations
  const filteredReservations = reservations.filter((r) => {
    const matchesSearch =
      r.customerName.toLowerCase().includes(resSearch.toLowerCase()) ||
      r.phone.includes(resSearch) ||
      r.serviceName.toLowerCase().includes(resSearch.toLowerCase());
    const matchesStatus = resStatusFilter === 'all' || r.status === resStatusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="bg-[#FAF7F5] min-h-screen border-b border-stone-300 pb-24 font-sans">
      
      {/* Top Admin Header Bar */}
      <div className="bg-stone-900 text-white sticky top-0 z-40 border-b border-stone-800 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-md bg-[#9E6B5D] flex items-center justify-center font-bold text-white shadow-2xs">
                <Sliders className="w-4 h-4" />
              </div>
              <div>
                <span className="font-bold text-sm sm:text-base tracking-wide">
                  광소장 살롱 CMS 관리자 센터
                </span>
                <span className="text-[10px] text-stone-400 block sm:inline sm:ml-2">
                  실시간 콘텐츠·예약·디자인 통합 제어판
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={downloadCurrentHtml}
                disabled={isDownloading}
                className="px-3.5 py-2 rounded-lg bg-stone-800 hover:bg-stone-700 text-amber-300 text-xs font-bold flex items-center gap-1.5 transition-all border border-stone-700 active:scale-98 disabled:opacity-50"
                title="모바일 오프라인용 단독 HTML 파일 다운로드"
              >
                <Download className="w-3.5 h-3.5" />
                <span>{isDownloading ? 'HTML 생성 중...' : '모바일용 HTML 다운로드'}</span>
              </button>
              <button
                onClick={() => setIsAdmin(false)}
                className="px-4 py-2 rounded-lg bg-[#9E6B5D] hover:bg-[#845346] text-white text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs active:scale-98"
              >
                <Eye className="w-4 h-4" />
                <span>사용자 화면(사이트)으로 나가기</span>
              </button>
            </div>
          </div>

          {/* Admin Navigation Tabs */}
          <div className="flex items-center space-x-1 overflow-x-auto pb-2 sm:pb-0 no-scrollbar text-xs font-semibold">
            <button
              onClick={() => setAdminTab('dashboard')}
              className={`px-3.5 py-2.5 rounded-t-lg transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                adminTab === 'dashboard'
                  ? 'bg-[#FAF7F5] text-stone-900 border-t-2 border-[#9E6B5D]'
                  : 'text-stone-400 hover:text-white'
              }`}
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>대시보드 &amp; 예약 관리 ({reservations.length})</span>
            </button>

            <button
              onClick={() => setAdminTab('posts')}
              className={`px-3.5 py-2.5 rounded-t-lg transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                adminTab === 'posts'
                  ? 'bg-[#FAF7F5] text-stone-900 border-t-2 border-[#9E6B5D]'
                  : 'text-stone-400 hover:text-white'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>게시글 &amp; 이벤트 CMS ({posts.length})</span>
            </button>

            <button
              onClick={() => setAdminTab('services')}
              className={`px-3.5 py-2.5 rounded-t-lg transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                adminTab === 'services'
                  ? 'bg-[#FAF7F5] text-stone-900 border-t-2 border-[#9E6B5D]'
                  : 'text-stone-400 hover:text-white'
              }`}
            >
              <Gem className="w-3.5 h-3.5" />
              <span>시술 메뉴 &amp; 가격 ({services.length})</span>
            </button>

            <button
              onClick={() => setAdminTab('gallery')}
              className={`px-3.5 py-2.5 rounded-t-lg transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                adminTab === 'gallery'
                  ? 'bg-[#FAF7F5] text-stone-900 border-t-2 border-[#9E6B5D]'
                  : 'text-stone-400 hover:text-white'
              }`}
            >
              <Image className="w-3.5 h-3.5" />
              <span>갤러리 &amp; 이달의아트 ({gallery.length})</span>
            </button>

            <button
              onClick={() => setAdminTab('theme')}
              className={`px-3.5 py-2.5 rounded-t-lg transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                adminTab === 'theme'
                  ? 'bg-[#FAF7F5] text-stone-900 border-t-2 border-[#9E6B5D]'
                  : 'text-stone-400 hover:text-white'
              }`}
            >
              <Palette className="w-3.5 h-3.5" />
              <span>디자인 테마 &amp; 텍스트</span>
            </button>

            <button
              onClick={() => setAdminTab('seo')}
              className={`px-3.5 py-2.5 rounded-t-lg transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                adminTab === 'seo'
                  ? 'bg-[#FAF7F5] text-stone-900 border-t-2 border-[#9E6B5D]'
                  : 'text-stone-400 hover:text-white'
              }`}
            >
              <Globe className="w-3.5 h-3.5" />
              <span>SEO &amp; 소셜 연동</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Admin Content Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        
        {/* ==================================================== */}
        {/* TAB 1: RESERVATIONS DASHBOARD */}
        {/* ==================================================== */}
        {adminTab === 'dashboard' && (
          <div className="space-y-8 animate-in fade-in duration-200">
            
            {/* KPI Cards */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-2xs">
                <div className="text-xs text-stone-500 font-semibold">총 접수 예약</div>
                <div className="text-2xl font-serif-luxury font-bold text-stone-900 mt-1">
                  {reservations.length}건
                </div>
                <div className="text-[11px] text-stone-400 mt-1">실시간 동기화 상태</div>
              </div>

              <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-2xs">
                <div className="text-xs text-amber-600 font-semibold">대기 중 (확인요망)</div>
                <div className="text-2xl font-serif-luxury font-bold text-amber-600 mt-1">
                  {reservations.filter((r) => r.status === 'pending').length}건
                </div>
                <div className="text-[11px] text-stone-400 mt-1">카톡/전화 상담 필요</div>
              </div>

              <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-2xs">
                <div className="text-xs text-emerald-600 font-semibold">확정된 예약</div>
                <div className="text-2xl font-serif-luxury font-bold text-emerald-600 mt-1">
                  {reservations.filter((r) => r.status === 'confirmed').length}건
                </div>
                <div className="text-[11px] text-stone-400 mt-1">배정 완료</div>
              </div>

              <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-2xs">
                <div className="text-xs text-stone-500 font-semibold">예상 시술 매출액</div>
                <div className="text-2xl font-serif-luxury font-bold text-[#9E6B5D] mt-1">
                  ₩{reservations.reduce((sum, r) => sum + (r.status !== 'cancelled' ? r.totalPrice : 0), 0).toLocaleString()}
                </div>
                <div className="text-[11px] text-stone-400 mt-1">취소 건 제외 합산</div>
              </div>
            </div>

            {/* Reservations Table Area */}
            <div className="bg-white rounded-2xl p-6 border border-stone-200 shadow-xs space-y-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <h3 className="font-serif-luxury text-xl font-bold text-stone-900">
                  실시간 예약 목록 관리
                </h3>

                {/* Filters & Search */}
                <div className="flex flex-wrap items-center gap-2.5 w-full sm:w-auto">
                  <div className="relative flex-1 sm:w-60">
                    <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-stone-400" />
                    <input
                      type="text"
                      placeholder="고객명 / 전화번호 검색"
                      value={resSearch}
                      onChange={(e) => setResSearch(e.target.value)}
                      className="w-full pl-8 pr-3 py-1.5 text-xs border border-stone-300 rounded-md focus:outline-hidden focus:ring-1 focus:ring-stone-500"
                    />
                  </div>

                  <select
                    value={resStatusFilter}
                    onChange={(e) => setResStatusFilter(e.target.value)}
                    className="text-xs border border-stone-300 rounded-md px-2.5 py-1.5 bg-white text-stone-700"
                  >
                    <option value="all">모든 상태</option>
                    <option value="pending">대기 중</option>
                    <option value="confirmed">예약 확정</option>
                    <option value="completed">시술 완료</option>
                    <option value="cancelled">예약 취소</option>
                  </select>
                </div>
              </div>

              {/* Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-stone-700">
                  <thead className="bg-stone-50 text-stone-500 uppercase tracking-wider font-semibold border-y border-stone-200">
                    <tr>
                      <th className="py-3 px-4">고객 정보</th>
                      <th className="py-3 px-4">일시 / 시간</th>
                      <th className="py-3 px-4">시술 &amp; 담당자</th>
                      <th className="py-3 px-4">추가 옵션 / 메모</th>
                      <th className="py-3 px-4">예상 금액</th>
                      <th className="py-3 px-4">상태 변경</th>
                      <th className="py-3 px-4 text-right">삭제</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100 font-medium">
                    {filteredReservations.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="text-center py-10 text-stone-400">
                          검색 조건에 맞는 예약이 없습니다.
                        </td>
                      </tr>
                    ) : (
                      filteredReservations.map((res) => (
                        <tr key={res.id} className="hover:bg-stone-50/80 transition-colors">
                          <td className="py-3.5 px-4 font-bold text-stone-900">
                            <div>{res.customerName}</div>
                            <div className="text-[11px] text-stone-500 font-normal">{res.phone}</div>
                          </td>
                          <td className="py-3.5 px-4">
                            <div className="font-bold text-stone-800">{res.date}</div>
                            <div className="text-[11px] text-[#9E6B5D] font-bold">{res.time}</div>
                          </td>
                          <td className="py-3.5 px-4">
                            <div className="font-bold text-stone-900">{res.serviceName}</div>
                            <div className="text-[11px] text-stone-500">담당: {res.artistName}</div>
                          </td>
                          <td className="py-3.5 px-4 max-w-xs">
                            {res.addOns.length > 0 && (
                              <div className="text-[11px] text-stone-600 font-normal mb-0.5">
                                + {res.addOns.join(', ')}
                              </div>
                            )}
                            {res.requestNotes ? (
                              <div className="text-[10px] text-stone-400 italic truncate">
                                "{res.requestNotes}"
                              </div>
                            ) : (
                              <span className="text-[10px] text-stone-300">-</span>
                            )}
                          </td>
                          <td className="py-3.5 px-4 font-bold text-stone-900">
                            ₩{res.totalPrice.toLocaleString()}
                          </td>
                          <td className="py-3.5 px-4">
                            <select
                              value={res.status}
                              onChange={(e) =>
                                updateReservationStatus(res.id, e.target.value as ReservationStatus)
                              }
                              className={`text-[11px] font-bold px-2 py-1 rounded-md border ${
                                res.status === 'confirmed'
                                  ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                                  : res.status === 'pending'
                                  ? 'bg-amber-50 text-amber-800 border-amber-300'
                                  : res.status === 'completed'
                                  ? 'bg-blue-50 text-blue-800 border-blue-300'
                                  : 'bg-stone-100 text-stone-500 border-stone-300'
                              }`}
                            >
                              <option value="pending">대기 중</option>
                              <option value="confirmed">예약 확정</option>
                              <option value="completed">시술 완료</option>
                              <option value="cancelled">예약 취소</option>
                            </select>
                          </td>
                          <td className="py-3.5 px-4 text-right">
                            <button
                              onClick={() => deleteReservation(res.id)}
                              className="text-stone-400 hover:text-rose-600 p-1 transition-colors"
                              title="삭제"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {/* ==================================================== */}
        {/* TAB 2: POSTS & ARTICLES CMS */}
        {/* ==================================================== */}
        {adminTab === 'posts' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-serif-luxury text-2xl font-bold text-stone-900">
                  게시글 &amp; 이벤트 소식 관리
                </h3>
                <p className="text-xs text-stone-500">
                  이달의 프로모션, 네일/속눈썹 홈케어 가이드, 공지사항을 쉽게 등록하고 편집하세요.
                </p>
              </div>

              {!isAddingPost && (
                <button
                  onClick={() => {
                    setEditingPostId(null);
                    setPostTitle('');
                    setPostSummary('');
                    setPostContent('');
                    setIsAddingPost(true);
                  }}
                  className="px-4 py-2 rounded-md bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold flex items-center gap-1.5 shadow-xs"
                >
                  <Plus className="w-4 h-4" />
                  <span>새 게시글 작성</span>
                </button>
              )}
            </div>

            {/* Add / Edit Form */}
            {isAddingPost && (
              <form
                onSubmit={handleSavePost}
                className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm space-y-4"
              >
                <div className="flex items-center justify-between border-b border-stone-100 pb-3">
                  <h4 className="font-bold text-sm text-stone-900">
                    {editingPostId ? '게시글 수정' : '새 게시글 / 이벤트 등록'}
                  </h4>
                  <button
                    type="button"
                    onClick={() => setIsAddingPost(false)}
                    className="p-1 text-stone-400 hover:text-stone-700"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      게시글 제목 *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="예: 2026 가을 이달의 아트 컬렉션 공개"
                      value={postTitle}
                      onChange={(e) => setPostTitle(e.target.value)}
                      className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md focus:ring-1 focus:ring-stone-500 focus:outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      카테고리
                    </label>
                    <select
                      value={postCategory}
                      onChange={(e) => setPostCategory(e.target.value as any)}
                      className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md focus:ring-1 focus:ring-stone-500 focus:outline-hidden"
                    >
                      <option value="이벤트">이벤트</option>
                      <option value="네일아트 팁">네일아트 팁</option>
                      <option value="속눈썹 가이드">속눈썹 가이드</option>
                      <option value="살롱 소식">살롱 소식</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      작성자
                    </label>
                    <input
                      type="text"
                      value={postAuthor}
                      onChange={(e) => setPostAuthor(e.target.value)}
                      className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md focus:ring-1 focus:ring-stone-500 focus:outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      태그 (쉼표로 구분)
                    </label>
                    <input
                      type="text"
                      placeholder="이달의아트, 가을네일, 할인"
                      value={postTags}
                      onChange={(e) => setPostTags(e.target.value)}
                      className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md focus:ring-1 focus:ring-stone-500 focus:outline-hidden"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    커버 이미지 URL
                  </label>
                  <input
                    type="url"
                    value={postCoverImage}
                    onChange={(e) => setPostCoverImage(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md focus:ring-1 focus:ring-stone-500 focus:outline-hidden font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    한 줄 요약 (카드 미리보기에 표시)
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="핵심 요약 한 문장을 적어주세요."
                    value={postSummary}
                    onChange={(e) => setPostSummary(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md focus:ring-1 focus:ring-stone-500 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    본문 내용 (마크다운 및 줄바꿈 지원)
                  </label>
                  <textarea
                    rows={6}
                    required
                    placeholder="게시글 상세 내용을 입력해주세요."
                    value={postContent}
                    onChange={(e) => setPostContent(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md focus:ring-1 focus:ring-stone-500 focus:outline-hidden"
                  />
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsAddingPost(false)}
                    className="px-4 py-2 text-xs font-semibold text-stone-600 bg-stone-100 hover:bg-stone-200 rounded-md"
                  >
                    취소
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 text-xs font-semibold text-white bg-stone-900 hover:bg-stone-800 rounded-md shadow-xs"
                  >
                    {editingPostId ? '수정 완료' : '게시글 발행'}
                  </button>
                </div>
              </form>
            )}

            {/* Posts List */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {posts.map((p) => (
                <div
                  key={p.id}
                  className="bg-white p-5 rounded-xl border border-stone-200 shadow-2xs flex flex-col justify-between space-y-4"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-sm bg-stone-100 text-[#9E6B5D]">
                        {p.category}
                      </span>
                      <span className="text-[11px] text-stone-400">{p.publishDate}</span>
                    </div>

                    <h4 className="font-bold text-sm text-stone-900 line-clamp-1">{p.title}</h4>
                    <p className="text-xs text-stone-500 line-clamp-2">{p.summary}</p>
                  </div>

                  <div className="pt-3 border-t border-stone-100 flex items-center justify-between">
                    <span className="text-[11px] text-stone-500">작성자: {p.author}</span>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          setEditingPostId(p.id);
                          setPostTitle(p.title);
                          setPostCategory(p.category);
                          setPostSummary(p.summary);
                          setPostContent(p.content);
                          setPostCoverImage(p.coverImage);
                          setPostAuthor(p.author);
                          setPostTags(p.tags.join(', '));
                          setIsAddingPost(true);
                        }}
                        className="p-1 text-stone-500 hover:text-stone-900"
                        title="수정"
                      >
                        <Edit className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => deletePost(p.id)}
                        className="p-1 text-stone-400 hover:text-rose-600"
                        title="삭제"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

          </div>
        )}

        {/* ==================================================== */}
        {/* TAB 3: SERVICES & PRICING CMS */}
        {/* ==================================================== */}
        {adminTab === 'services' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-serif-luxury text-2xl font-bold text-stone-900">
                  시술 프로그램 &amp; 가격 메뉴 관리
                </h3>
                <p className="text-xs text-stone-500">
                  정찰제 가격표, 소요 시간, 상세 설명, 포함 옵션을 실시간으로 추가 및 변경하세요.
                </p>
              </div>

              {!isAddingService && (
                <button
                  onClick={() => {
                    setEditingSrvId(null);
                    setSrvName('');
                    setSrvDesc('');
                    setIsAddingService(true);
                  }}
                  className="px-4 py-2 rounded-md bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold flex items-center gap-1.5 shadow-xs"
                >
                  <Plus className="w-4 h-4" />
                  <span>새 시술 메뉴 등록</span>
                </button>
              )}
            </div>

            {/* Service Form */}
            {isAddingService && (
              <form
                onSubmit={handleSaveService}
                className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm space-y-4"
              >
                <div className="flex items-center justify-between border-b border-stone-100 pb-3">
                  <h4 className="font-bold text-sm text-stone-900">
                    {editingSrvId ? '시술 메뉴 수정' : '새 시술 메뉴 추가'}
                  </h4>
                  <button
                    type="button"
                    onClick={() => setIsAddingService(false)}
                    className="p-1 text-stone-400 hover:text-stone-700"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      시술명 *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="예: 프리미엄 오로라 시럽 네일"
                      value={srvName}
                      onChange={(e) => setSrvName(e.target.value)}
                      className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      카테고리
                    </label>
                    <select
                      value={srvCategory}
                      onChange={(e) => setSrvCategory(e.target.value as any)}
                      className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md"
                    >
                      <option value="monthly_art">이달의 아트</option>
                      <option value="nail_art">핸드 젤네일</option>
                      <option value="eyelash">속눈썹 펌/연장</option>
                      <option value="pedicure">페디 &amp; 풋스파</option>
                      <option value="special">스페셜/웨딩</option>
                      <option value="care">손톱 건강 케어</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      뱃지 텍스트
                    </label>
                    <input
                      type="text"
                      placeholder="BEST HIT, SIGNATURE, 추천"
                      value={srvBadge}
                      onChange={(e) => setSrvBadge(e.target.value)}
                      className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      시술 가격 (원) *
                    </label>
                    <input
                      type="number"
                      required
                      value={srvPrice}
                      onChange={(e) => setSrvPrice(Number(e.target.value))}
                      className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      정가/할인 전 가격 (선택)
                    </label>
                    <input
                      type="number"
                      value={srvOriginalPrice || ''}
                      onChange={(e) => setSrvOriginalPrice(e.target.value ? Number(e.target.value) : undefined)}
                      className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      소요 시간 (분)
                    </label>
                    <input
                      type="number"
                      value={srvDuration}
                      onChange={(e) => setSrvDuration(Number(e.target.value))}
                      className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    대표 이미지 URL
                  </label>
                  <input
                    type="url"
                    value={srvImage}
                    onChange={(e) => setSrvImage(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    상세 설명
                  </label>
                  <textarea
                    rows={2}
                    required
                    value={srvDesc}
                    onChange={(e) => setSrvDesc(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    포함 혜택 및 상세 옵션 (쉼표로 구분)
                  </label>
                  <input
                    type="text"
                    value={srvOptions}
                    onChange={(e) => setSrvOptions(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md"
                  />
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsAddingService(false)}
                    className="px-4 py-2 text-xs font-semibold text-stone-600 bg-stone-100 hover:bg-stone-200 rounded-md"
                  >
                    취소
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 text-xs font-semibold text-white bg-stone-900 hover:bg-stone-800 rounded-md"
                  >
                    {editingSrvId ? '메뉴 수정 저장' : '메뉴 추가 등록'}
                  </button>
                </div>
              </form>
            )}

            {/* Services List */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {services.map((s) => (
                <div
                  key={s.id}
                  className="bg-white p-5 rounded-xl border border-stone-200 shadow-2xs flex flex-col justify-between space-y-4"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-sm bg-stone-100 text-stone-700">
                        {s.categoryLabel}
                      </span>
                      <span className="font-bold text-sm text-stone-900">
                        ₩{s.price.toLocaleString()}
                      </span>
                    </div>

                    <h4 className="font-bold text-sm text-stone-900">{s.name}</h4>
                    <p className="text-xs text-stone-500 line-clamp-2">{s.description}</p>
                    <span className="text-[11px] text-stone-400 block">소요시간: {s.durationMin}분</span>
                  </div>

                  <div className="pt-3 border-t border-stone-100 flex items-center justify-end gap-2">
                    <button
                      onClick={() => {
                        setEditingSrvId(s.id);
                        setSrvName(s.name);
                        setSrvCategory(s.category);
                        setSrvPrice(s.price);
                        setSrvOriginalPrice(s.originalPrice);
                        setSrvDuration(s.durationMin);
                        setSrvDesc(s.description);
                        setSrvBadge(s.badge || '');
                        setSrvImage(s.image);
                        setSrvOptions(s.includedOptions.join(', '));
                        setIsAddingService(true);
                      }}
                      className="p-1 text-stone-500 hover:text-stone-900"
                      title="수정"
                    >
                      <Edit className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => deleteService(s.id)}
                      className="p-1 text-stone-400 hover:text-rose-600"
                      title="삭제"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

          </div>
        )}

        {/* ==================================================== */}
        {/* TAB 4: GALLERY & MONTHLY ART CMS */}
        {/* ==================================================== */}
        {adminTab === 'gallery' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-serif-luxury text-2xl font-bold text-stone-900">
                  포트폴리오 갤러리 &amp; 이달의 아트 관리
                </h3>
                <p className="text-xs text-stone-500">
                  고화질 시술 사진, 태그, 디자이너, 이달의 아트 지정 여부를 손쉽게 관리하세요.
                </p>
              </div>

              {!isAddingGallery && (
                <button
                  onClick={() => {
                    setGalTitle('');
                    setGalDesc('');
                    setIsAddingGallery(true);
                  }}
                  className="px-4 py-2 rounded-md bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold flex items-center gap-1.5 shadow-xs"
                >
                  <Plus className="w-4 h-4" />
                  <span>새 작품 등록</span>
                </button>
              )}
            </div>

            {/* Gallery Form */}
            {isAddingGallery && (
              <form
                onSubmit={handleSaveGallery}
                className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm space-y-4"
              >
                <div className="flex items-center justify-between border-b border-stone-100 pb-3">
                  <h4 className="font-bold text-sm text-stone-900">새 갤러리 작품 등록</h4>
                  <button
                    type="button"
                    onClick={() => setIsAddingGallery(false)}
                    className="p-1 text-stone-400 hover:text-stone-700"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      작품 타이틀 *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="예: 샴페인 펄 오로라 시럽"
                      value={galTitle}
                      onChange={(e) => setGalTitle(e.target.value)}
                      className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      카테고리
                    </label>
                    <select
                      value={galCategory}
                      onChange={(e) => setGalCategory(e.target.value as any)}
                      className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md"
                    >
                      <option value="monthly_art">이달의 아트</option>
                      <option value="nail_art">핸드 젤네일</option>
                      <option value="eyelash">속눈썹 시술</option>
                      <option value="pedicure">페디큐어</option>
                      <option value="special">스페셜/웨딩</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      시술 가격 (원)
                    </label>
                    <input
                      type="number"
                      value={galPrice}
                      onChange={(e) => setGalPrice(Number(e.target.value))}
                      className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      담당 아티스트
                    </label>
                    <select
                      value={galArtist}
                      onChange={(e) => setGalArtist(e.target.value)}
                      className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md"
                    >
                      <option value="광소장 원장">광소장 원장</option>
                      <option value="지유 수석 아티스트">지유 수석 아티스트</option>
                      <option value="하은 래쉬 디렉터">하은 래쉬 디렉터</option>
                    </select>
                  </div>

                  <div className="flex items-center gap-2 pt-6">
                    <input
                      type="checkbox"
                      id="isMonthly"
                      checked={galIsMonthly}
                      onChange={(e) => setGalIsMonthly(e.target.checked)}
                      className="rounded-xs text-[#9E6B5D]"
                    />
                    <label htmlFor="isMonthly" className="text-xs font-semibold text-stone-800">
                      ✨ 이달의 아트 홈 화면 추천 노출
                    </label>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    사진 이미지 URL *
                  </label>
                  <input
                    type="url"
                    required
                    value={galImage}
                    onChange={(e) => setGalImage(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    태그 (쉼표로 구분)
                  </label>
                  <input
                    type="text"
                    value={galTags}
                    onChange={(e) => setGalTags(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    작품 설명
                  </label>
                  <textarea
                    rows={2}
                    value={galDesc}
                    onChange={(e) => setGalDesc(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md"
                  />
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsAddingGallery(false)}
                    className="px-4 py-2 text-xs font-semibold text-stone-600 bg-stone-100 hover:bg-stone-200 rounded-md"
                  >
                    취소
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 text-xs font-semibold text-white bg-stone-900 hover:bg-stone-800 rounded-md"
                  >
                    작품 등록 완료
                  </button>
                </div>
              </form>
            )}

            {/* Gallery Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              {gallery.map((item) => (
                <div
                  key={item.id}
                  className="bg-white rounded-xl overflow-hidden border border-stone-200 shadow-2xs flex flex-col justify-between"
                >
                  <div className="relative aspect-square bg-stone-100">
                    <img
                      src={item.imageUrl}
                      alt={item.title}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                    {item.isMonthlyArt && (
                      <span className="absolute top-2 left-2 bg-amber-500 text-white text-[9px] font-bold px-2 py-0.5 rounded-full">
                        이달의 아트
                      </span>
                    )}
                  </div>

                  <div className="p-3">
                    <h5 className="font-bold text-xs text-stone-900 truncate">{item.title}</h5>
                    <div className="flex items-center justify-between text-[11px] text-stone-500 mt-1">
                      <span>{item.artist}</span>
                      <span className="font-bold text-stone-800">
                        {item.price ? `₩${item.price.toLocaleString()}` : ''}
                      </span>
                    </div>

                    <div className="pt-2 mt-2 border-t border-stone-100 flex justify-end">
                      <button
                        onClick={() => deleteGalleryItem(item.id)}
                        className="text-stone-400 hover:text-rose-600 p-1"
                        title="삭제"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

          </div>
        )}

        {/* ==================================================== */}
        {/* TAB 5: THEME, COLORS & CONTENT CUSTOMIZER */}
        {/* ==================================================== */}
        {adminTab === 'theme' && (
          <div className="space-y-10 animate-in fade-in duration-200">
            
            {/* Color Palette Selector */}
            <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-6">
              <div>
                <h3 className="font-serif-luxury text-xl font-bold text-stone-900">
                  원클릭 럭셔리 살롱 테마 팔레트
                </h3>
                <p className="text-xs text-stone-500">
                  클릭 한 번으로 전체 웹사이트의 브랜드 컬러, 버튼, 하이라이트 톤이 일괄 변환됩니다.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
                {Object.entries(THEME_PALETTES).map(([key, item]) => {
                  const isSelected = siteConfig.theme.paletteId === key;
                  return (
                    <div
                      key={key}
                      onClick={() => selectThemePalette(key)}
                      className={`p-4 rounded-xl border-2 transition-all cursor-pointer space-y-3 ${
                        isSelected
                          ? 'border-[#9E6B5D] bg-[#FAF2ED] shadow-sm'
                          : 'border-stone-200 bg-stone-50 hover:bg-white'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span
                          className="w-5 h-5 rounded-full shadow-2xs shrink-0"
                          style={{ backgroundColor: item.theme.primaryColor }}
                        />
                        <span
                          className="w-4 h-4 rounded-full shadow-2xs shrink-0"
                          style={{ backgroundColor: item.theme.accentColor }}
                        />
                      </div>
                      <div>
                        <div className="font-bold text-xs text-stone-900">{item.name}</div>
                        <div className="text-[10px] text-stone-500 line-clamp-2 mt-0.5">
                          {item.description}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Custom Hex Pickers */}
              <div className="pt-4 border-t border-stone-100 grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    메인 브랜드 컬러 (Primary Hex)
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={siteConfig.theme.primaryColor}
                      onChange={(e) => updateTheme({ primaryColor: e.target.value })}
                      className="w-8 h-8 rounded-md border border-stone-300 cursor-pointer"
                    />
                    <input
                      type="text"
                      value={siteConfig.theme.primaryColor}
                      onChange={(e) => updateTheme({ primaryColor: e.target.value })}
                      className="text-xs px-2.5 py-1.5 border border-stone-300 rounded-md font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    골드/액센트 컬러 (Accent Hex)
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={siteConfig.theme.accentColor}
                      onChange={(e) => updateTheme({ accentColor: e.target.value })}
                      className="w-8 h-8 rounded-md border border-stone-300 cursor-pointer"
                    />
                    <input
                      type="text"
                      value={siteConfig.theme.accentColor}
                      onChange={(e) => updateTheme({ accentColor: e.target.value })}
                      className="text-xs px-2.5 py-1.5 border border-stone-300 rounded-md font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    배경 톤 (Light BG Hex)
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={siteConfig.theme.bgLight}
                      onChange={(e) => updateTheme({ bgLight: e.target.value })}
                      className="w-8 h-8 rounded-md border border-stone-300 cursor-pointer"
                    />
                    <input
                      type="text"
                      value={siteConfig.theme.bgLight}
                      onChange={(e) => updateTheme({ bgLight: e.target.value })}
                      className="text-xs px-2.5 py-1.5 border border-stone-300 rounded-md font-mono"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Site Branding & Information Editor */}
            <form
              onSubmit={handleSaveBranding}
              className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-5"
            >
              <div>
                <h3 className="font-serif-luxury text-xl font-bold text-stone-900">
                  살롱 기본 정보 &amp; 문구 커스터마이징
                </h3>
                <p className="text-xs text-stone-500">
                  샵 상호명, 슬로건, 공지바 텍스트, 전화번호, 주소, 영업시간을 자유롭게 변경할 수 있습니다.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    샵 상호명 (Brand Name)
                  </label>
                  <input
                    type="text"
                    required
                    value={brandForm.brandName}
                    onChange={(e) => setBrandForm({ ...brandForm, brandName: e.target.value })}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    영문 표기명
                  </label>
                  <input
                    type="text"
                    value={brandForm.englishName}
                    onChange={(e) => setBrandForm({ ...brandForm, englishName: e.target.value })}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    메인 슬로건
                  </label>
                  <input
                    type="text"
                    value={brandForm.tagline}
                    onChange={(e) => setBrandForm({ ...brandForm, tagline: e.target.value })}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    대표 전화번호
                  </label>
                  <input
                    type="text"
                    value={brandForm.phone}
                    onChange={(e) => setBrandForm({ ...brandForm, phone: e.target.value })}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  서브 헤드라인 설명 문구
                </label>
                <textarea
                  rows={2}
                  value={brandForm.subTagline}
                  onChange={(e) => setBrandForm({ ...brandForm, subTagline: e.target.value })}
                  className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md"
                />
              </div>

              {/* Announcement Bar */}
              <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 space-y-3">
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="annToggle"
                    checked={brandForm.announcementEnabled}
                    onChange={(e) =>
                      setBrandForm({ ...brandForm, announcementEnabled: e.target.checked })
                    }
                    className="rounded-xs text-[#9E6B5D]"
                  />
                  <label htmlFor="annToggle" className="text-xs font-bold text-stone-900">
                    상단 공지 띠배너 활성화
                  </label>
                </div>
                <input
                  type="text"
                  placeholder="공지 배너 문구를 입력하세요"
                  value={brandForm.announcementText}
                  onChange={(e) =>
                    setBrandForm({ ...brandForm, announcementText: e.target.value })
                  }
                  className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md bg-white"
                />
              </div>

              {/* Location & Parking */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    도로명 주소
                  </label>
                  <input
                    type="text"
                    value={brandForm.address}
                    onChange={(e) => setBrandForm({ ...brandForm, address: e.target.value })}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    상세 오시는 길 안내
                  </label>
                  <input
                    type="text"
                    value={brandForm.addressDetail}
                    onChange={(e) => setBrandForm({ ...brandForm, addressDetail: e.target.value })}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    지하철 안내
                  </label>
                  <input
                    type="text"
                    value={brandForm.subwayInfo}
                    onChange={(e) => setBrandForm({ ...brandForm, subwayInfo: e.target.value })}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    주차 및 발렛파킹 안내
                  </label>
                  <input
                    type="text"
                    value={brandForm.parkingInfo}
                    onChange={(e) => setBrandForm({ ...brandForm, parkingInfo: e.target.value })}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md"
                  />
                </div>
              </div>

              {/* Business Hours */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    평일 영업시간
                  </label>
                  <input
                    type="text"
                    value={brandForm.weekdayHours}
                    onChange={(e) => setBrandForm({ ...brandForm, weekdayHours: e.target.value })}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    토요일 영업시간
                  </label>
                  <input
                    type="text"
                    value={brandForm.saturdayHours}
                    onChange={(e) => setBrandForm({ ...brandForm, saturdayHours: e.target.value })}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    휴무일 공지
                  </label>
                  <input
                    type="text"
                    value={brandForm.holidayNotice}
                    onChange={(e) => setBrandForm({ ...brandForm, holidayNotice: e.target.value })}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md"
                  />
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-md bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold shadow-xs flex items-center gap-1.5"
                >
                  <Save className="w-4 h-4" />
                  <span>정보 변경사항 저장</span>
                </button>
              </div>
            </form>

            {/* Data Backup & Reset Box */}
            <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-4">
              <div className="flex items-center gap-2">
                <Database className="w-5 h-5 text-stone-700" />
                <div>
                  <h4 className="font-bold text-sm text-stone-900">
                    데이터 백업 및 초기 샘플 복원
                  </h4>
                  <p className="text-xs text-stone-500">
                    전체 데이터를 JSON 파일로 내보내거나, 초기 샘플 플레이스홀더 데이터로 되돌릴 수 있습니다.
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  onClick={exportDataJson}
                  className="px-4 py-2 text-xs font-semibold bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-md flex items-center gap-1.5 border border-stone-300"
                >
                  <Download className="w-4 h-4" />
                  <span>JSON 데이터 내보내기 (백업)</span>
                </button>

                <button
                  onClick={resetToSampleData}
                  className="px-4 py-2 text-xs font-semibold bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-md flex items-center gap-1.5 border border-rose-200"
                >
                  <RefreshCw className="w-4 h-4" />
                  <span>초기 샘플 데이터로 복구 (Reset)</span>
                </button>
              </div>
            </div>

          </div>
        )}

        {/* ==================================================== */}
        {/* TAB 6: SEO & SOCIAL MEDIA INTEGRATION */}
        {/* ==================================================== */}
        {adminTab === 'seo' && (
          <div className="space-y-8 animate-in fade-in duration-200">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              
              {/* Left Settings Form */}
              <div className="lg:col-span-7 space-y-6">
                <form
                  onSubmit={handleSaveSeo}
                  className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-5"
                >
                  <div>
                    <h3 className="font-serif-luxury text-xl font-bold text-stone-900">
                      SEO 검색엔진 최적화 &amp; 소셜 채널 연동
                    </h3>
                    <p className="text-xs text-stone-500">
                      네이버·구글 검색 결과 및 카카오톡 공유 시 표시되는 메타 정보를 설정하세요.
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      SEO 웹사이트 타이틀 (Title Tag)
                    </label>
                    <input
                      type="text"
                      value={seoForm.title}
                      onChange={(e) => setSeoForm({ ...seoForm, title: e.target.value })}
                      className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      SEO 메타 설명문 (Meta Description)
                    </label>
                    <textarea
                      rows={3}
                      value={seoForm.description}
                      onChange={(e) => setSeoForm({ ...seoForm, description: e.target.value })}
                      className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      검색 키워드 (쉼표 구분)
                    </label>
                    <input
                      type="text"
                      value={seoForm.keywords}
                      onChange={(e) => setSeoForm({ ...seoForm, keywords: e.target.value })}
                      className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      SNS 공유 썸네일 이미지 URL (og:image)
                    </label>
                    <input
                      type="url"
                      value={seoForm.ogImage}
                      onChange={(e) => setSeoForm({ ...seoForm, ogImage: e.target.value })}
                      className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md font-mono"
                    />
                  </div>

                  {/* Social links */}
                  <div className="pt-3 border-t border-stone-100 space-y-3">
                    <h4 className="font-bold text-xs text-stone-800">
                      소셜 미디어 및 외부 예약 채널 URL
                    </h4>

                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <span className="w-20 text-xs text-stone-500 shrink-0">인스타그램</span>
                        <input
                          type="url"
                          value={seoForm.instagram}
                          onChange={(e) => setSeoForm({ ...seoForm, instagram: e.target.value })}
                          className="w-full px-3 py-1.5 text-xs border border-stone-300 rounded-md"
                        />
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="w-20 text-xs text-stone-500 shrink-0">카카오 채널</span>
                        <input
                          type="url"
                          value={seoForm.kakaoChannel}
                          onChange={(e) => setSeoForm({ ...seoForm, kakaoChannel: e.target.value })}
                          className="w-full px-3 py-1.5 text-xs border border-stone-300 rounded-md"
                        />
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="w-20 text-xs text-stone-500 shrink-0">네이버 예약</span>
                        <input
                          type="url"
                          value={seoForm.naverBooking}
                          onChange={(e) => setSeoForm({ ...seoForm, naverBooking: e.target.value })}
                          className="w-full px-3 py-1.5 text-xs border border-stone-300 rounded-md"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-end pt-2">
                    <button
                      type="submit"
                      className="px-6 py-2.5 rounded-md bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold shadow-xs flex items-center gap-1.5"
                    >
                      <Save className="w-4 h-4" />
                      <span>SEO 및 소셜 설정 저장</span>
                    </button>
                  </div>
                </form>
              </div>

              {/* Right Live Preview Simulators */}
              <div className="lg:col-span-5 space-y-6">
                
                {/* Google Search Snippet Simulator */}
                <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs space-y-3">
                  <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wider block">
                    구글 / 네이버 검색 결과 실시간 시뮬레이터
                  </span>

                  <div className="bg-[#F8F9FA] p-4 rounded-xl border border-stone-200 font-sans space-y-1.5">
                    <div className="text-[11px] text-stone-500 flex items-center gap-1">
                      <span>https://kwang-nail.com</span>
                      <span>›</span>
                      <span>boutique</span>
                    </div>
                    <h4 className="text-sm font-semibold text-[#1a0dab] hover:underline cursor-pointer line-clamp-1">
                      {seoForm.title || siteConfig.seo.title}
                    </h4>
                    <p className="text-xs text-stone-600 line-clamp-2 leading-relaxed">
                      {seoForm.description || siteConfig.seo.description}
                    </p>
                  </div>
                </div>

                {/* KakaoTalk Share Card Simulator */}
                <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs space-y-3">
                  <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wider block">
                    카카오톡 링크 공유 카드 미리보기
                  </span>

                  <div className="bg-[#BACEE0] p-4 rounded-xl flex justify-center">
                    <div className="bg-white rounded-xl overflow-hidden shadow-md max-w-xs w-full">
                      <div className="aspect-16/9 bg-stone-200 relative overflow-hidden">
                        <img
                          src={seoForm.ogImage || siteConfig.seo.ogImage}
                          alt="og thumbnail"
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                      <div className="p-3.5 space-y-1">
                        <h5 className="font-bold text-xs text-stone-900 line-clamp-1">
                          {siteConfig.brandName} | 프리미엄 젤네일 &amp; 속눈썹
                        </h5>
                        <p className="text-[11px] text-stone-500 line-clamp-2 leading-tight">
                          {seoForm.description || siteConfig.seo.description}
                        </p>
                        <span className="text-[9px] text-stone-400 block pt-1">kwang-nail.com</span>
                      </div>
                    </div>
                  </div>
                </div>

              </div>

            </div>
          </div>
        )}

      </div>
    </div>
  );
};
