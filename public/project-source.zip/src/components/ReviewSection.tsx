import React, { useState } from 'react';
import { useSalon } from '../context/SalonContext';
import { submitToFormspree } from '../utils/formspree';
import {
  Star,
  CheckCircle2,
  ThumbsUp,
  MessageSquarePlus,
  X,
  Sparkles,
} from 'lucide-react';

export const ReviewSection: React.FC = () => {
  const { siteConfig, reviews, addReview, showToast } = useSalon();
  const [isWriteModalOpen, setIsWriteModalOpen] = useState(false);

  // New review form state
  const [authorName, setAuthorName] = useState('');
  const [rating, setRating] = useState(5);
  const [serviceName, setServiceName] = useState('이달의 아트');
  const [staffName, setStaffName] = useState('광소장 원장');
  const [comment, setComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!authorName.trim() || !comment.trim()) return;

    setIsSubmitting(true);

    // Save to local context
    addReview({
      author: `${authorName.trim().slice(0, 1)}*${authorName.trim().slice(-1) || '님'} 고객님`,
      rating,
      serviceName,
      comment: comment.trim(),
      verified: true,
      staffName,
    });

    // Submit to Formspree
    await submitToFormspree({
      form_type: '고객 방문 리얼 후기 작성',
      author_name: authorName.trim(),
      star_rating: `${rating} / 5 점`,
      received_service: serviceName,
      staff_name: staffName,
      review_comment: comment.trim(),
    });

    setIsSubmitting(false);
    showToast('소중한 후기 등록 완료', '리뷰가 성공적으로 등록 및 전송되었습니다.');
    setAuthorName('');
    setComment('');
    setIsWriteModalOpen(false);
  };

  return (
    <section id="reviews" className="py-16 sm:py-24 bg-white border-t border-[#EAE3DE]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div className="space-y-3 max-w-2xl">
            <span
              className="text-xs font-bold uppercase tracking-widest block font-sans"
              style={{ color: siteConfig.theme.primaryColor }}
            >
              Real Customer Reviews
            </span>
            <h2 className="font-serif-luxury text-3xl sm:text-4xl font-bold text-stone-900">
              고객님들이 증명하는 100% 리얼 후기
            </h2>
            <p className="text-sm sm:text-base text-stone-600">
              꼼꼼한 케어와 높은 유지력, 1:1 맞춤 상담으로 만족하신 실제 방문 고객님들의 솔직한 이야기입니다.
            </p>
          </div>

          {/* Quick Rating Summary & Write Button */}
          <div className="flex items-center gap-4 shrink-0">
            <div className="bg-[#FAF6F2] p-4 rounded-xl border border-[#E8DDD5] flex items-center gap-3">
              <div className="text-center">
                <div className="text-2xl font-serif-luxury font-bold text-stone-900">4.98</div>
                <div className="flex text-amber-500 text-xs">
                  {'★'.repeat(5)}
                </div>
              </div>
              <div className="text-xs text-stone-500 border-l border-stone-200 pl-3">
                <div>방문 만족도 <strong>99.8%</strong></div>
                <div>누적 리뷰 <strong>340+</strong>건</div>
              </div>
            </div>

            <button
              onClick={() => setIsWriteModalOpen(true)}
              className="px-4 py-3.5 rounded-xl bg-stone-900 hover:bg-stone-800 text-white text-xs sm:text-sm font-semibold flex items-center gap-2 shadow-xs transition-all"
            >
              <MessageSquarePlus className="w-4 h-4" />
              <span>후기 작성하기</span>
            </button>
          </div>
        </div>

        {/* Reviews Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {reviews.map((rev) => (
            <div
              key={rev.id}
              className="bg-[#FAF7F5] rounded-xl p-6 border border-[#E8DDD5] shadow-2xs hover:shadow-md transition-shadow flex flex-col justify-between space-y-4"
            >
              <div className="space-y-3">
                {/* Header */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1 text-amber-500">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star
                        key={i}
                        className={`w-3.5 h-3.5 ${
                          i < rev.rating ? 'fill-amber-400 text-amber-400' : 'text-stone-300'
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-[11px] text-stone-400">{rev.date}</span>
                </div>

                {/* Service Tag */}
                <div className="flex items-center gap-1.5 text-xs text-[#8C6D62] font-semibold">
                  <Sparkles className="w-3 h-3 text-amber-600" />
                  <span>{rev.serviceName}</span>
                </div>

                {/* Comment Body */}
                <p className="text-xs sm:text-sm text-stone-700 leading-relaxed">
                  "{rev.comment}"
                </p>
              </div>

              {/* Footer */}
              <div className="pt-3 border-t border-[#E8DDD5] flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5 text-stone-800 font-medium">
                  <span>{rev.author}</span>
                  {rev.verified && (
                    <span className="inline-flex items-center text-[10px] text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded-sm font-semibold">
                      <CheckCircle2 className="w-2.5 h-2.5 mr-0.5" /> 인증방문
                    </span>
                  )}
                </div>

                <span className="text-stone-500 text-[11px]">
                  담당: {rev.staffName}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Review Modal Form */}
        {isWriteModalOpen && (
          <div
            className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4"
            onClick={() => setIsWriteModalOpen(false)}
          >
            <div
              className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-stone-200 animate-in zoom-in-95 duration-150 relative"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={() => setIsWriteModalOpen(false)}
                className="absolute top-4 right-4 p-1.5 rounded-full text-stone-400 hover:text-stone-700 hover:bg-stone-100"
              >
                <X className="w-5 h-5" />
              </button>

              <h3 className="font-serif-luxury text-xl font-bold text-stone-900 mb-1">
                시술 후기 작성
              </h3>
              <p className="text-xs text-stone-500 mb-5">
                광소장 살롱에서의 경험을 들려주세요. 소중한 의견은 더 나은 서비스의 밑거름이 됩니다.
              </p>

              <form onSubmit={handleSubmit} className="space-y-4">
                {/* Rating Select */}
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                    별점 선택
                  </label>
                  <div className="flex gap-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        type="button"
                        key={star}
                        onClick={() => setRating(star)}
                        className="p-1 text-2xl focus:outline-hidden"
                      >
                        <Star
                          className={`w-6 h-6 ${
                            star <= rating
                              ? 'fill-amber-400 text-amber-400'
                              : 'text-stone-300'
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>

                {/* Author Name */}
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    고객명 (익명 마스킹 처리됨)
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="예: 김민지"
                    value={authorName}
                    onChange={(e) => setAuthorName(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md focus:ring-1 focus:ring-stone-500 focus:outline-hidden"
                  />
                </div>

                {/* Service Name */}
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    받으신 시술
                  </label>
                  <select
                    value={serviceName}
                    onChange={(e) => setServiceName(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md focus:ring-1 focus:ring-stone-500 focus:outline-hidden"
                  >
                    <option value="이달의 아트">이달의 아트</option>
                    <option value="프리미엄 커스텀 드로잉 젤네일">프리미엄 커스텀 드로잉 젤네일</option>
                    <option value="블랙 틴팅 노글루 속눈썹 펌">블랙 틴팅 노글루 속눈썹 펌</option>
                    <option value="100% 에어플랫모 속눈썹 연장">100% 에어플랫모 속눈썹 연장</option>
                    <option value="힐링 스파 페디큐어">힐링 스파 페디큐어</option>
                    <option value="오트쿠튀르 웨딩 네일">오트쿠튀르 웨딩 네일</option>
                  </select>
                </div>

                {/* Staff Name */}
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    담당 아티스트
                  </label>
                  <select
                    value={staffName}
                    onChange={(e) => setStaffName(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md focus:ring-1 focus:ring-stone-500 focus:outline-hidden"
                  >
                    <option value="광소장 원장">광소장 원장</option>
                    <option value="지유 수석 아티스트">지유 수석 아티스트</option>
                    <option value="하은 래쉬 디렉터">하은 래쉬 디렉터</option>
                  </select>
                </div>

                {/* Review Text */}
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    후기 내용
                  </label>
                  <textarea
                    required
                    rows={4}
                    placeholder="시술 만족도, 디자인 완성도, 살롱 분위기 등을 자유롭게 적어주세요."
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-md focus:ring-1 focus:ring-stone-500 focus:outline-hidden resize-none"
                  />
                </div>

                {/* Submit */}
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3 rounded-md text-white font-semibold text-xs shadow-xs hover:opacity-90 transition-opacity disabled:opacity-50"
                  style={{ backgroundColor: siteConfig.theme.primaryColor }}
                >
                  {isSubmitting ? '후기 등록 및 전송 중...' : '후기 등록하기'}
                </button>
              </form>
            </div>
          </div>
        )}

      </div>
    </section>
  );
};
